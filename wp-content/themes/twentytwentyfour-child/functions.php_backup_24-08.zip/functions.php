<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array(  ) );
        wp_enqueue_style('swiper-css', get_stylesheet_directory_uri() . '/assist/css/swiper-bundle.min.css');
        // wp_enqueue_style('fontawesome', get_stylesheet_directory_uri() . '/assist/css/all.min.css');
        wp_enqueue_script('swiper-js', get_stylesheet_directory_uri() . '/assist/js/swiper-bundle.min.js', array('jquery'), null, true);
        wp_enqueue_script('custom-js', get_stylesheet_directory_uri() . '/assist/js/custom.js', array('jquery'), null, true);
        wp_localize_script('custom-ajax-script', 'custom_ajax_obj', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('custom_ajax_nonce')
    ));
        wp_enqueue_script('matchheight', get_stylesheet_directory_uri() . '/assist/js/jquery.matchHeight-min.js', array('jquery'), null, true);
        wp_enqueue_script('progressbar', get_stylesheet_directory_uri() . '/assist/js/chart.min.js', array('jquery'), null, true);
         // Enqueue WooCommerce styles if not already enqueued
    if (class_exists('WooCommerce')) {
        wp_enqueue_style('woocommerce-general');
        wp_enqueue_style('woocommerce-layout');
        wp_enqueue_style('woocommerce-smallscreen');
    }
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

function mytheme_setup() {
    add_theme_support('widgets');
}
add_action('after_setup_theme', 'mytheme_setup');

function mytheme_register_widget_areas() {
    register_sidebar(array(
        'name'          => __('Primary Sidebar', 'mytheme'),
        'id'            => 'primary-sidebar',
        'description'   => __('Widgets in this area will be shown on all posts and pages.', 'mytheme'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'mytheme_register_widget_areas');

// Shortcode to display the primary sidebar
function mytheme_display_primary_sidebar($atts) {
    ob_start();
    if (is_active_sidebar('primary-sidebar')) {
        dynamic_sidebar('primary-sidebar');
    }
    return ob_get_clean();
}
add_shortcode('primary_sidebar', 'mytheme_display_primary_sidebar');


add_action( 'add_meta_boxes', 'product_meta_box_add' );
function product_meta_box_add() {
   add_meta_box( 'my-meta-box-id', 'All Custom Field', 'product_field', 'product', 'normal', 'high' );
}

function product_field( $post ) {
   $difficulty = get_post_meta(get_the_ID(),'difficulty',true);
   $THC = get_post_meta(get_the_ID(),'THC_live',true);
   $Flower_Time = get_post_meta(get_the_ID(),'Flower_Time_live',true);
   $type = get_post_meta(get_the_ID(),'type',true);
    $CBD  = get_post_meta(get_the_ID(),'CBD_live',true);
    $planttype  = get_post_meta(get_the_ID(),'planttype',true);
    $Effects  = get_post_meta(get_the_ID(),'Effects',true);
    $relieves  = get_post_meta(get_the_ID(),'relieves',true);
   ?>
<style type="text/css">
.custom-data input[type=text] {
    width: 400px;
}

.custom-data textarea {
    width: 80%;
}

.custom-data label {
    width: 110px;
    float: left;
}
</style>
<div class="custom-data">
    <p>
        <label for="planttype"> Difficulty :</label>
        <input type="text" name="difficulty" id="difficulty" value="<?php echo $difficulty; ?>" />
    </p>
    <p>
        <label for="planttype"> Plant Type :</label>
        <input type="text" name="planttype" id="planttype" value="<?php echo $planttype; ?>" />
    </p>
    <p>
        <label for="difficulty"> THC :</label>
        <input type="text" name="THC_live" id="THC_live" value="<?php echo $THC; ?>" />
    </p>
    <p>
        <label for="difficulty"> CBD :</label>
        <input type="text" name="CBD_live" id="CBD_live" value="<?php echo $CBD; ?>" />
    </p>
    <p>
        <label for="difficulty"> Flower Time :</label>
        <input type="text" name="Flower_Time_live" id="Flower_Time_live" value="<?php echo $Flower_Time; ?>" />
    </p>
    <p>
        <label for="Effects"> Effects :</label>
        <input type="text" name="Effects" id="Effects" value="<?php echo $Effects; ?>" />
    </p>
    <p>
        <label for="relieves"> Relieves :</label>
        <input type="text" name="relieves" id="relieves" value="<?php echo $relieves; ?>" />
    </p>
</div>
<?php   
}

add_action( 'save_post', 'addproduct_meta_box_save' );
function addproduct_meta_box_save( $post_id ) {
  if( isset( $_POST[ 'difficulty' ] ) ) {
     update_post_meta($post_id, 'difficulty',$_POST[ 'difficulty' ]);
   }
   if( isset( $_POST[ 'THC_live' ] ) ) {
     update_post_meta($post_id, 'THC_live',$_POST[ 'THC_live' ]);
   }
   if( isset( $_POST[ 'Flower_Time_live' ] ) ) {
     update_post_meta($post_id, 'Flower_Time_live',$_POST[ 'Flower_Time_live' ]);
   }
   if( isset( $_POST[ 'type' ] ) ) {
     update_post_meta($post_id, 'type',$_POST[ 'type' ]);
   }
   if( isset( $_POST[ 'type' ] ) ) {
    update_post_meta($post_id, 'type',$_POST[ 'type' ]);
  }
  if( isset( $_POST[ 'CBD_live' ] ) ) {
    update_post_meta($post_id, 'CBD_live',$_POST[ 'CBD_live' ]);
  }
  if( isset( $_POST[ 'planttype' ] ) ) {
    update_post_meta($post_id, 'planttype',$_POST[ 'planttype' ]);
  }
  if( isset( $_POST[ 'Effects' ] ) ) {
    update_post_meta($post_id, 'Effects',$_POST[ 'Effects' ]);
  }
  if( isset( $_POST[ 'relieves' ] ) ) {
    update_post_meta($post_id, 'relieves',$_POST[ 'relieves' ]);
  }
}


// Function to get the city from URL and display it
function display_city_name_from_url() {
    // Get the current URL
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    // Parse the URL to get the query parameters
    $url_parts = parse_url($current_url);
    parse_str($url_parts['query'], $query_params);

    // Get the 'city' parameter value
    $city_name = isset($query_params['city']) ? sanitize_text_field($query_params['city']) : '';

    // If city name is found, return it, otherwise return a default message
    return !empty($city_name) ? '<h2 class="city-title">' . esc_html($city_name) . '</h2>' : '<h2>No city specified</h2>';
}

// Create a shortcode to use the function
add_shortcode('show_city_name', 'display_city_name_from_url');

// END ENQUEUE PARENT ACTION

function wc_category_tabs_shortcode($atts) {
    $product_categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
    ));

    ob_start(); ?>

    <div class="tabs-wrapper">
        <div class="tabs">
            <ul class="tab-links">
                <li><a href="#latest">Top Picks</a></li>
                <?php 
                foreach($product_categories as $category) :
                    $checkbox_value = get_field('categories_checkbox', 'product_cat_' . $category->term_id);
                    if (is_array($checkbox_value) && in_array('yes', $checkbox_value)) : ?>
                        <li><a href="#<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?></a></li>
                    <?php 
                    endif;
                endforeach; 
                ?>
            </ul>
        </div>

        <div class="tab-content-wrapper">
            <div id="latest" class="tab-content">
                <div class="category-details match-height">
                    <h2>Top Picks</h2>
                    <div class="category-image">
                        <img src="/wordpress/eighthsounces_new/wp-content/uploads/2024/07/Group-1000002380.svg" alt="Top Pick">
                    </div>
                    <a href="/wordpress/eighthsounces_new/shop1/" class="shop-link">Shop All</a>
                </div>
                <div class="products-container swiper-container match-height">
                    <div class="swiper-wrapper">
                        <?php
                            $latest_query = new WP_Query(array(
                                'post_type' => 'product',
                                'posts_per_page' => 10, 
                                'orderby' => 'date',
                                'order' => 'DESC'
                            ));
                            if($latest_query->have_posts()) : while($latest_query->have_posts()) : $latest_query->the_post(); 
                                global $product;
                            ?>
                        <div class="product-item swiper-slide">
                            <a href="<?php echo get_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"></a>
                            <h2><?php the_title(); ?></h2>
                            <?php 
                                $average = $product->get_average_rating();
                                $review_count = $product->get_review_count();
                            ?>
                            <ul class="woocommerce">
                                <?php if ($average) : ?>
                                    <li>
                                        <div class="star-rating" title="<?php echo sprintf(__('Rated %s out of 5', 'woocommerce'), $average); ?>">
                                            <span style="width:<?php echo (($average / 5) * 100); ?>%">
                                                <strong itemprop="ratingValue" class="rating"><?php echo $average; ?></strong> <?php _e('out of 5', 'woocommerce'); ?>
                                            </span>
                                        </div>
                                        <span class="comment-count">(<?php echo esc_html($review_count); ?>)</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                            <div class="price"><?php echo $product->get_price_html(); ?></div>
                        </div>
                        <?php endwhile; wp_reset_postdata(); endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
            <?php 
            foreach($product_categories as $category) :
                $checkbox_value = get_field('categories_checkbox', 'product_cat_' . $category->term_id);
                if (is_array($checkbox_value) && in_array('yes', $checkbox_value)) : ?>
                <div id="<?php echo esc_attr($category->slug); ?>" class="tab-content">
                    <div class="category-details match-height">
                        <h2><?php echo esc_html($category->name); ?></h2>
                        <div class="category-image">
                            <?php woocommerce_subcategory_thumbnail($category); ?>
                        </div>
                        <a href="<?php echo get_term_link($category); ?>" class="shop-link">Shop All</a>
                    </div>
                    <div class="products-container swiper-container match-height">
                        <div class="swiper-wrapper">
                            <?php
                                $query = new WP_Query(array(
                                    'post_type' => 'product',
                                    'posts_per_page' => 10,
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'product_cat',
                                            'field'    => 'slug',
                                            'terms'    => $category->slug,
                                        ),
                                    ),
                                ));
                                if($query->have_posts()) : while($query->have_posts()) : $query->the_post(); 
                                    global $product;
                                ?>
                            <div class="product-item swiper-slide">
                                <a href="<?php echo get_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"></a>
                                <h2><?php the_title(); ?></h2>
                                <?php 
                                    $average = $product->get_average_rating();
                                    $review_count = $product->get_review_count();
                                ?>
                                <ul class="woocommerce">
                                    <?php if ($average) : ?>
                                        <li>
                                            <div class="star-rating" title="<?php echo sprintf(__('Rated %s out of 5', 'woocommerce'), $average); ?>">
                                                <span style="width:<?php echo (($average / 5) * 100); ?>%">
                                                    <strong itemprop="ratingValue" class="rating"><?php echo $average; ?></strong> <?php _e('out of 5', 'woocommerce'); ?>
                                                </span>
                                            </div>
                                            <span class="comment-count">(<?php echo esc_html($review_count); ?>)</span>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <div class="price"><?php echo $product->get_price_html(); ?></div>
                            </div>
                            <?php endwhile; wp_reset_postdata(); endif; ?>
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
                <?php 
                endif;
            endforeach; 
            ?>
        </div>
    </div>

<script>
jQuery(document).ready(function($) {
    function initializeSwiper() {
        $('.tab-content').each(function() {
            var swiperContainer = $(this).find('.swiper-container');
            if (swiperContainer.length) {
                new Swiper(swiperContainer.get(0), {
                    slidesPerView: 1,
                    spaceBetween: 24,
                    loop: true,
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    },
                    pagination: {
                        el: '.swiper-pagination',
                        type: 'fraction',
                    },
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    breakpoints: {
                        500: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 24,
                        },
                        1024: {
                            slidesPerView: 4,
                            spaceBetween: 24,
                        },
                    },
                });
            }
        });

        $('.tab-content .match-height').matchHeight();
        $('.product-item img').matchHeight();
    }

    $('.tab-links a').on('click', function(e) {
        e.preventDefault();
        var currentAttrValue = $(this).attr('href');

        $('.tab-content-wrapper ' + currentAttrValue).css('display', 'flex').siblings('.tab-content').hide();

        $(this).parent('li').addClass('active').siblings().removeClass('active');

        initializeSwiper();
    });

    $('.tab-links li:first-child').addClass('active');
    $('#latest').css('display', 'flex').siblings('.tab-content').hide();

    initializeSwiper();
});
</script>
<?php
    return ob_get_clean();
}
add_shortcode('wc_category_tabs', 'wc_category_tabs_shortcode');


// Start the session to track user activity
if (!function_exists('custom_wc_start_session')) {
    add_action('init', 'custom_wc_start_session', 1);
    function custom_wc_start_session() {
        if (!session_id()) {
            session_start();
        }
    }
}

// Create the shortcode to display recently viewed products with Swiper slider
if (!function_exists('custom_wc_recently_viewed_products_shortcode')) {
    add_shortcode('custom_recently_viewed_products', 'custom_wc_recently_viewed_products_shortcode');
    function custom_wc_recently_viewed_products_shortcode($atts) {
        if (empty($_SESSION['custom_recently_viewed'])) {
            return '<div class="no-recently-viewed-products">
                        <h2>No recently viewed products</h2>
                        <p>Get back to shopping - check out our <a href="/weekly-ad">weekly ad</a> for the latest sales.</p>
                    </div>';
        }

        $recently_viewed = $_SESSION['custom_recently_viewed'];

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post__in' => $recently_viewed,
            'orderby' => 'post__in'
        );

        $query = new WP_Query($args);

        if (!$query->have_posts()) {
            return '<div class="no-recently-viewed-products">
                        <h2>No recently viewed products</h2>
                        <p>Get back to shopping - check out our <a href="/weekly-ad">weekly ad</a> for the latest sales.</p>
                    </div>';
        }

        ob_start();

        echo '<div class="recentview-container swiper-container">';
        echo '<div class="swiper-wrapper">';

        while ($query->have_posts()) : $query->the_post();
            global $product;

            echo '<div class="swiper-slide">';
            echo '<li>';
            echo '<a href="' . get_permalink() . '">';
            echo woocommerce_get_product_thumbnail(); // Product image
            echo '</a>';
            echo '<h2 class="woocommerce-loop-product__title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
            echo '<span class="price">' . $product->get_price_html() . '</span>'; // Product price
            echo wc_get_rating_html($product->get_average_rating()); // Product rating
            echo '</li>';
            echo '</div>';

        endwhile;

        echo '</div>'; // .swiper-wrapper
        echo '<div class="swiper-pagination"></div>';
        echo '<div class="swiper-button-next"></div>';
        echo '<div class="swiper-button-prev"></div>';
        echo '</div>'; // .swiper-container

        wp_reset_postdata();

        return ob_get_clean();
    }
}


// Register custom shortcode to display posts in a grid
function custom_post_grid_shortcode($atts) {
    // Shortcode attributes
    $atts = shortcode_atts(array(
        'posts_per_page' => 4,  // Number of posts per page
    ), $atts, 'post_grid');

    // Query arguments
    $args = array(
        'post_type' => 'post',  // Post type to query (you can change this to any custom post type)
        'posts_per_page' => $atts['posts_per_page'],  // Number of posts to display
    );

    $query = new WP_Query($args);

    // Start output buffering
    ob_start();

    if ($query->have_posts()) {
        echo '<div class="post-grid-container">';
        while ($query->have_posts()) {
            $query->the_post();
            ?>
<div class="post-item">
    <div class="post-thumbnail">
        <a href="<?php the_permalink(); ?>">
            <?php the_post_thumbnail('medium'); ?>
        </a>
    </div>
    <div class="post-content">
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
        <a class="learn-more" href="<?php the_permalink(); ?>">Learn More</a>
    </div>
</div>
<?php
        }
        echo '</div>';
        wp_reset_postdata();  // Restore original post data
    } else {
        echo '<p>No posts found</p>';
    }

    // End output buffering and return the content
    return ob_get_clean();
}
add_shortcode('post_grid', 'custom_post_grid_shortcode');

function todays_recommendations_shortcode($atts) {
    // Define default attributes
    $atts = shortcode_atts(
        array(
            'limit' => 4, // Number of products to display
        ), $atts, 'todays_recommendations'
    );

    // WP_Query arguments to fetch products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $atts['limit'],
        'meta_query' => array(
            array(
                'key' => 'recommendations_product', // ACF field key
                'value' => 'yes',
                'compare' => 'LIKE'
            ),
        ),
    );

    // Fetch products
    $loop = new WP_Query($args);

    // Start output buffer
    ob_start();

    // Check if there are any products
    if ($loop->have_posts()) {
        echo '<ul class="products todays-recommendations">';
        while ($loop->have_posts()) : $loop->the_post();
            global $product;
            $product_id = get_the_ID();
            $product_title = get_the_title();
            $product_link = get_permalink();
            $product_image = wp_get_attachment_image_src(get_post_thumbnail_id($product_id), 'single-post-thumbnail')[0];
            $thc = get_field('thc', $product_id);
            $cbd = get_field('cbd', $product_id);
            $type = get_field('type', $product_id);
            $flower_time = get_field('flower_time', $product_id);

            echo '<li class="product">';
            echo '<div class="product-top-right">';
            echo '<a href="?add-to-cart=' . $product_id . '&redirect_to_cart=1" class="add-to-cart"><img src="' . esc_url(get_stylesheet_directory_uri() . '/img/heard.svg') . '" alt="Add to Cart"></a>';
            echo '</div>';
            echo '<a href="' . esc_url($product_link) . '">';
            echo '<img class="recommendations_product_img" src="' . esc_url($product_image) . '" alt="' . esc_attr($product_title) . '">';
            echo '<h2>' . esc_html($product_title) . '</h2>';
            echo '</a>';
            echo '<div class="product-wrap">';
            echo '<div class="product-details">';
            echo '<div class="product-thc-cbd">';
            echo '<p><strong>THC:</strong> ' . esc_html($thc) . '</p>';
            echo '<p><strong>CBD:</strong> ' . esc_html($cbd) . '</p>';
            echo '</div>';
            echo '<div class="product-type-flower">';
            echo '<p><strong>Type:</strong> ' . esc_html($type) . '</p>';
            echo '<p><strong>Flower Time:</strong> ' . esc_html($flower_time) . '</p>';
            echo '</div>';
            echo '</div>';
            echo '<a href="' . esc_url($product_link) . '" class="button">View Product</a>';
            echo '</div>';
            echo '</li>';
        endwhile;
        echo '</ul>';
    } else {
        echo __('No recommendations found');
    }

    // Reset post data
    wp_reset_postdata();

    // Get the buffer content
    return ob_get_clean();
}
add_shortcode('todays_recommendations', 'todays_recommendations_shortcode');


function custom_products_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'category_id' => '30', // default category ID
        ), 
        $atts, 
        'custom_products'
    );

    $category_id = $atts['category_id'];

    // Query for products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 4,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id,
            ),
        ),
    );

    $query = new WP_Query($args);
    $output = '<div class="custom-products">';

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            global $product;

            $output .= '<div class="product">';
            $output .= '<div class="product-image">' . get_the_post_thumbnail($product->get_id(), 'medium') . '</div>';
            $output .= '<h2 class="product-title">' . get_the_title() . '</h2>';
            $output .= '<div class="product-description">' . get_the_excerpt() . '</div>';
            $output .= '<a class="shop-now-button" href="' . get_permalink() . '">Shop now</a>';
            $output .= '</div>';
        }
    } else {
        $output .= '<p>No products found in this category.</p>';
    }

    $output .= '</div>';
    wp_reset_postdata();

    return $output;
}
add_shortcode('custom_products', 'custom_products_shortcode');


// Add the sale timer shortcode
function sale_timer_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'product_id' => '154',
        ), $atts, 'sale_timer' );

    if (empty($atts['product_id'])) {
        return 'Product ID not specified.';
    }

    $product_id = $atts['product_id'];
    $product = wc_get_product($product_id);

    if (!$product->is_on_sale()) {
        return 'This product is not on sale.';
    }

    $sale_end_date = get_post_meta($product_id, '_sale_price_dates_to', true);

    if (empty($sale_end_date)) {
        return 'No end date set for the sale.';
    }

    $sale_end_date = date('Y-m-d H:i:s', $sale_end_date);

    ob_start();
    ?>
<div class="sale-timer" id="sale-timer-<?php echo $product_id; ?>"></div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var countDownDate = new Date("<?php echo $sale_end_date; ?>").getTime();

    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;

        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById("sale-timer-<?php echo $product_id; ?>").innerHTML = "Ends in " + days +
            "Day " + hours + "hrs " + minutes + "mins " + seconds + "sec";

        if (distance < 0) {
            clearInterval(x);
            document.getElementById("sale-timer-<?php echo $product_id; ?>").innerHTML = "SALE ENDED";
        }
    }, 1000);
});
</script>
<?php
    return ob_get_clean();
}
add_shortcode('sale_timer', 'sale_timer_shortcode');

// Add the sale products shortcode
function sale_products_shortcode($atts) {
    // Set default attributes and extract them
    $atts = shortcode_atts(
        array(
            'limit' => '4', // Number of products to display
        ), $atts, 'sale_products' );

    // Query arguments for WooCommerce sale products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $atts['limit'],
        'meta_query' => array(
            array(
                'key' => '_sale_price',
                'value' => 0,
                'compare' => '>',
                'type' => 'NUMERIC'
            )
        )
    );

    // Create a new WP_Query for sale products
    $sale_products = new WP_Query($args);

    // Start output buffering
    ob_start();
    
    if ($sale_products->have_posts()) {
        echo '<ul class="sale-products">';
        while ($sale_products->have_posts()) {
            $sale_products->the_post();
            global $product;
            ?>
<li>
    <a href="<?php the_permalink(); ?>">
        <?php echo woocommerce_get_product_thumbnail(); ?>
        <h2><?php the_title(); ?></h2>
    </a>
</li>
<?php
        }
        echo '</ul>';
    } else {
        echo 'No sale products found.';
    }
    
    // Reset post data
    wp_reset_postdata();

    // Return the output buffer content
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('sale_products_short', 'sale_products_shortcode');



function sale_products_shortcode_home($atts) {
    $atts = shortcode_atts(
        array(
            'limit' => '4', // Number of products to display
        ), $atts, 'sale_products' );

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $atts['limit'],
        'meta_query' => array(
            array(
                'key' => '_sale_price',
                'value' => 0,
                'compare' => '>',
                'type' => 'NUMERIC'
            )
        )
    );

    $sale_products = new WP_Query($args);
    ob_start();

    if ($sale_products->have_posts()) {
        ?>
        <div class="swiper-container sale-products-swiper">
            <div class="swiper-wrapper">
        <?php
        while ($sale_products->have_posts()) {
            $sale_products->the_post();
            global $product;
            ?>
            <div class="swiper-slide">
                <a href="<?php the_permalink(); ?>">
                    <?php echo woocommerce_get_product_thumbnail(); ?>
                    <h2><?php the_title(); ?></h2>
                </a>
            </div>
            <?php
        }
        ?>
            </div>
        </div>
   
        <?php
    } else {
        echo 'No sale products found.';
    }

    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('sale_products_home', 'sale_products_shortcode_home');

function display_sponsored_products($atts) {
    // Define default attributes
    $atts = shortcode_atts(
        array(
            'limit' => -1, // Number of products to display
        ), $atts, 'products_sponsored'
    );

    // WP_Query arguments to fetch products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $atts['limit'],
        'meta_query' => array(
            array(
                'key' => 'sponsored_products', // ACF field key
                'value' => 'yes',
                'compare' => 'LIKE'
            ),
        ),
    );

    // Fetch products
    $loop = new WP_Query($args);

    // Start output buffer
    ob_start();
    if ($loop->have_posts()) {
        echo '<div class="sponsored-products-grid">';
        echo '<div class="swiper-container">';
        echo '<div class="swiper-wrapper">';
    
        while ($loop->have_posts()) {
            $loop->the_post();
            global $product;
    
            $comment_count = get_comments_number($product->get_id());
            $product_link = get_permalink();
            $product_thumbnail = woocommerce_get_product_thumbnail();
            $product_title = get_the_title();
            $rating_html = $product->get_rating_count() ? '<div class="star-rating-container">' . wc_get_rating_html($product->get_average_rating()) . '</div>' : '';
            $comment_html = $comment_count > 0 ? '<div class="comment-count">(' . esc_html($comment_count) . ')</div>' : '';
            $price_html = $product->get_price_html();
            $add_to_cart_url = esc_url($product->add_to_cart_url());
            $add_to_cart_text = esc_html($product->add_to_cart_text());
    
            echo '<div class="swiper-slide">';
            echo '<div class="product">';
    
            echo '<div class="wishlist-button">' . do_shortcode('[yith_wcwl_add_to_wishlist]') . '</div>';
            echo '<a href="' . $product_link . '">' . $product_thumbnail . '</a>';
            echo '<h2 class="woocommerce-loop-product__title"><a href="' . $product_link . '">' . $product_title . '</a></h2>';
            echo '<div class="rating-wrap">';
            echo '<div class="rating-section woocommerce">';
            echo $rating_html;
            echo $comment_html;
            echo '</div>';
            echo '<span class="price">' . $price_html . '</span>';
            echo '</div>';
            echo '<a href="' . $add_to_cart_url . '" class="button add_to_cart_button">' . $add_to_cart_text . '</a>';
            echo '</div>';
            echo '</div>';
        }
    
        echo '</div>';
        echo '<div class="swiper-pagination"></div>';
        echo '<div class="swiper-button-next"></div>';
        echo '<div class="swiper-button-prev"></div>';
        echo '</div>';
        echo '</div>';
    } else {
        echo '<p>' . __('No sponsored products found', 'woocommerce') . '</p>';
    }
    
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('sponsored_products', 'display_sponsored_products');

function track_recently_viewed_products() {
    if (is_singular('product')) {
        global $post;

        if (empty($_COOKIE['recently_viewed_products'])) {
            $recently_viewed = array();
        } else {
            $recently_viewed = explode(',', $_COOKIE['recently_viewed_products']);
        }

        // Remove the current product if already viewed
        if (($key = array_search($post->ID, $recently_viewed)) !== false) {
            unset($recently_viewed[$key]);
        }

        // Add the current product ID to the beginning of the array
        array_unshift($recently_viewed, $post->ID);

        // Limit the number of recently viewed products to 5
        $recently_viewed = array_slice($recently_viewed, 0, 5);

        // Set the updated array back to the cookie
        setcookie('recently_viewed_products', implode(',', $recently_viewed), time() + 3600, '/');
    }
}
add_action('template_redirect', 'track_recently_viewed_products');


function display_recently_viewed_products() {
    if (empty($_COOKIE['recently_viewed_products'])) {
        return '<p>No products viewed recently.</p>';
    } else {
        $recently_viewed = explode(',', $_COOKIE['recently_viewed_products']);

        $args = array(
            'post_type' => 'product',
            'post__in' => $recently_viewed,
            'orderby' => 'post__in',
        );

        $recent_products = new WP_Query($args);

        if ($recent_products->have_posts()) {
            ob_start();
            ?>
<div class="recent-container">
    <div class="swiper-wrapper">
        <?php while ($recent_products->have_posts()) : $recent_products->the_post(); ?>
        <div class="swiper-slide">
            <a href="<?php echo get_permalink(); ?>">
                <?php echo get_the_post_thumbnail(get_the_ID(), 'shop_catalog'); ?>
                <h2><?php the_title(); ?></h2>
            </a>
        </div>
        <?php endwhile; ?>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
    <!-- Add Navigation -->
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</div>
<?php
            wp_reset_postdata();
            return ob_get_clean();
        } else {
            return '<p>No products viewed recently.</p>';
        }
    }
}
add_shortcode('recently_viewed_products', 'display_recently_viewed_products');


function allow_svg_upload( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'allow_svg_upload' );
function generate_progress_bar_shortcode() {
ob_start(); // Start output buffering
?>
<div class="progress-bar-grid" data-thc-progress-bar="<?php echo $thc_progress_bar; ?>">
    <?php 
    $thc_progress_bar = get_field('htc_progress_bar', get_the_ID());
    if (!$thc_progress_bar) {
        $thc_progress_bar = get_field('htc_progress_bar', 'option', get_the_ID());
    }
    if (!$thc_progress_bar) {
        $thc_progress_bar = 0; // Default value if not set
    }
    ?>
    <section class="progress-bar-section" data-thc-progress-bar="<?php echo esc_attr($thc_progress_bar); ?>">
        <span>THC</span><input type="range" value="<?php echo esc_attr($thc_progress_bar); ?>" min="0" max="100" hidden step="1"><canvas id="thcChart" width="150" height="150"></canvas>
    </section>
    <?php
    $cbd_progress_bar = get_field('cbd_progress_bar', get_the_ID());
    if (!$cbd_progress_bar) {
        $cbd_progress_bar = get_field('cbd_progress_bar', 'option', get_the_ID());
    }
    if (!$cbd_progress_bar) {
        $cbd_progress_bar = 0; // Default value if not set
    }
    ?>
    <section class="progress-bar-section" data-cbd-progress-bar="<?php echo esc_attr($cbd_progress_bar); ?>">
        <span>CBD</span><input type="range" value="<?php echo esc_attr($cbd_progress_bar); ?>" min="0" max="100" hidden step="1"><canvas id="cbdChart" width="150" height="150"></canvas>
    </section>
    <?php
        if( get_field('cat') ):
            $cat_image = get_field('cat', get_the_ID());
            $cat_name = get_field('cat_name', get_the_ID());
            $category_percentage = get_field('category_percentage', get_the_ID());
            ?>
    <section class="progress-bar-section cat-wrap">
        <div class="progress-bar-detail"><?php echo $cat_name; ?></div>
        <?php echo $cat_image; ?>
    </section>
    <?php
        else:
            $cat_image = get_field('cat', 'option', get_the_ID());
            ?>
    <section class="progress-bar-section">
    </section>
    <?php
        endif;
        if( get_field('time_of_use') ):
            $time_of_use = get_field('time_of_use', get_the_ID());
            ?>
    <section class="progress-bar-section">
        <span>Flower Time</span><?php echo $time_of_use; ?>
    </section>
    <?php
        else:
            $time_of_use = get_field('time_of_use', 'option', get_the_ID());
            ?>
    <section class="progress-bar-section">
        <span>Flower Time</span><?php echo $time_of_use; ?>
    </section>
    <?php
        endif;
    ?>
</div>


<?php
    return ob_get_clean(); // Return the buffered content
}

// Register the shortcode
add_shortcode('progress_bar', 'generate_progress_bar_shortcode');

// Shortcode for Typical Effects, May Relieve, Flavors, and Aromas
function custom_effects_shortcode() {
    ob_start();
    ?>
<div class="effects-grid">
    <div class="typical-effects-field-image">
        <div class="typical-image">
            <!-- Effect Profile -->
            <div class="effects-typical_heading typical--heading">
                <h3>Effect Profile</h3>
                <div class="effects-typical-image side-effects-section effects-section">
                    <?php
                    $typical_effects = get_field('typical_effects', get_the_ID());
                    if (empty($typical_effects)) {
                        $typical_effects = get_field('typical_effects', 'option');
                    }
                    if (is_array($typical_effects)) {
                        foreach ($typical_effects as $index => $term) :
                            $image = get_field('product_taxonomy_img', 'term_' . $term->term_id);
                            ?>
                            <div class="taxonomy-img-heading-section<?php echo $index >= 4 ? ' hidden' : ''; ?>">
                                <div class="taxonomy-img-heading">
                                    <div class="img"><img src="<?php echo esc_url($image); ?>"></div>
                                    <h4><?php echo esc_html($term->name); ?></h4>
                                </div>
                            </div>
                        <?php
                        endforeach;
                    }
                    ?>
                </div>
                <?php if (is_array($typical_effects) && count($typical_effects) > 4) : ?>
                    <p class="more-effects side-effects-more">See More</p>
                <?php endif; ?>
            </div>

            <!-- Relief Profile -->
            <div class="effects-typical_heading typical--heading">
                <h3>Relief Profile</h3>
                <div class="effects-typical-image may-relive-section effects-section">
                    <?php
                    $commonusage = get_field('common_usage', get_the_ID());
                    if (empty($commonusage)) {
                        $commonusage = get_field('common_usage', 'option');
                    }
                    if (is_array($commonusage)) {
                        foreach ($commonusage as $index => $term) :
                            $image = get_field('product_taxonomy_img', 'term_' . $term->term_id);
                            ?>
                            <div class="taxonomy-img-heading-section<?php echo $index >= 4 ? ' hidden' : ''; ?>">
                                <div class="taxonomy-img-heading">
                                    <div class="img"><img src="<?php echo esc_url($image); ?>"></div>
                                    <h4><?php echo esc_html($term->name); ?></h4>
                                </div>
                            </div>
                        <?php
                        endforeach;
                    }
                    ?>
                </div>
                <?php if (is_array($commonusage) && count($commonusage) > 4) : ?>
                    <p class="more-effects may-relive-more">See More</p>
                <?php endif; ?>
            </div>

            <!-- Flavors -->
            <div class="effects-typical_heading typical--heading">
                <h3>Flavors</h3>
                <div class="effects-typical-image flavors-section effects-section">
                    <?php
                    $flavors = get_field('flavors', get_the_ID());
                    if (empty($flavors)) {
                        $flavors = get_field('flavors', 'option');
                    }
                    if (is_array($flavors)) {
                        foreach ($flavors as $index => $term) :
                            $image = get_field('product_taxonomy_img', 'term_' . $term->term_id);
                            ?>
                            <div class="taxonomy-img-heading-section<?php echo $index >= 4 ? ' hidden' : ''; ?>">
                                <div class="taxonomy-img-heading">
                                    <div class="img"><img src="<?php echo esc_url($image); ?>"></div>
                                    <h4><?php echo esc_html($term->name); ?></h4>
                                </div>
                            </div>
                        <?php
                        endforeach;
                    }
                    ?>
                </div>
                <?php if (is_array($flavors) && count($flavors) > 4) : ?>
                    <p class="more-effects flavors-more">See More</p>
                <?php endif; ?>
            </div>

            <!-- Aromas -->
            <div class="effects-typical_heading typical--heading">
                <h3>Aromas</h3>
                <div class="effects-typical-image aromas-section effects-section">
                    <?php
                    $aromas = get_field('aromas', get_the_ID());
                    if (empty($aromas)) {
                        $aromas = get_field('aromas', 'option');
                    }
                    if (is_array($aromas)) {
                        foreach ($aromas as $index => $term) :
                            $image = get_field('product_taxonomy_img', 'term_' . $term->term_id);
                            ?>
                            <div class="taxonomy-img-heading-section<?php echo $index >= 4 ? ' hidden' : ''; ?>">
                                <div class="taxonomy-img-heading">
                                    <div class="img"><img src="<?php echo esc_url($image); ?>"></div>
                                    <h4><?php echo esc_html($term->name); ?></h4>
                                </div>
                            </div>
                        <?php
                        endforeach;
                    }
                    ?>
                </div>
                <?php if (is_array($aromas) && count($aromas) > 4) : ?>
                    <p class="more-effects aromas-more">See More</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php
    return ob_get_clean();
}

add_shortcode('custom_effects', 'custom_effects_shortcode');

add_filter ( 'woocommerce_product_thumbnails_columns', 'bbloomer_change_gallery_columns' );

function bbloomer_change_gallery_columns() {
return 1;
}

add_action('woocommerce_single_product_summary', 'display_specific_shipping_class', 15);
function display_specific_shipping_class() {
global $product;

// Check if the $product is available
if ( ! is_a( $product, 'WC_Product' ) ) {
$product = wc_get_product();
}

if ( ! is_a( $product, 'WC_Product' ) ) {
return; // Exit if $product is still not available
}

// Define your targeted shipping class name
$defined_shipping_class = "Estimated Delivery in 7-15 days";

// Get the product shipping class
$product_shipping_class = $product->get_shipping_class();

// Get the product shipping class term name
$term = get_term_by('slug', $product_shipping_class, 'product_shipping_class');

if ($term && $term->name == $defined_shipping_class) {
echo '<p class="product-shipping-class">' . esc_html($term->name) . '</p>';
}
}

function display_child_categories_with_details_shortcode_dynamic() {
    if (!is_product()) {
        return 'This shortcode can only be used on product pages.';
    }

    // Get the current product categories
    $product_id = get_the_ID();
    $categories = get_the_terms($product_id, 'product_cat');

    if (empty($categories) || is_wp_error($categories)) {
        return 'No categories found for this product.';
    }

    $child_categories = [];
    $is_seed = false;
    $is_strain = false;
    $selected_sub_category = null;
    $selected_parent_category = null;

    // Determine if the product belongs to "seed" or "strain" category
    foreach ($categories as $category) {
        if ($category->slug == 'seed') {
            $is_seed = true;
            // Get the first child categories within sub-categories
            $sub_categories = get_terms([
                'taxonomy' => 'product_cat',
                'parent'   => $category->term_id,
                'hide_empty' => false,
            ]);
            foreach ($sub_categories as $sub_category) {
                $child_categories = get_terms([
                    'taxonomy' => 'product_cat',
                    'parent'   => $sub_category->term_id,
                    'hide_empty' => false,
                ]);
                if (!empty($child_categories)) {
                    break; // Found child categories, stop further searching
                }
            }
            $selected_sub_category = $category; // Use the "seed" category for checking
            break; // Stop checking once we find the category
        } elseif ($category->slug == 'strain') {
            $is_strain = true;
            $selected_parent_category = $category;
            // Get child categories directly under the "strain" parent category
            $child_categories = get_terms([
                'taxonomy' => 'product_cat',
                'parent'   => $category->term_id,
                'hide_empty' => false,
            ]);
            break; // Stop checking once we find the category
        }
    }

    // If no child categories are found, return a message
    if (empty($child_categories)) {
        return 'No child categories found.';
    }

    // Display only the child categories
    $output = '<ul class="seed-cat">';
    $default_selected = false;

    foreach ($child_categories as $category) {
        $class = '';
        if (!$default_selected) {
            $class = ' class="selected-category"';
            $default_selected = true;
        }
        $output .= '<li' . $class . ' data-category-id="' . esc_attr($category->term_id) . '">';
        $output .= '<strong>' . esc_html($category->name) . '</strong>';
        $output .= '<p>' . esc_html($category->description) . '</p>';
        $output .= '</li>';
    }

    $output .= '</ul>';

    // Add JavaScript to make categories selectable and save selected category
    $output .= '
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const categoryItems = document.querySelectorAll(".seed-cat li");
            categoryItems.forEach(function(item) {
                item.addEventListener("click", function() {
                    categoryItems.forEach(function(item) {
                        item.classList.remove("selected-category");
                    });
                    item.classList.add("selected-category");
                });
            });
            // Update the add to cart form with the selected category ID
            const addToCartForm = document.querySelector("form.cart");
            addToCartForm.addEventListener("submit", function(event) {
                const selectedCategory = document.querySelector(".seed-cat .selected-category");
                if (selectedCategory) {
                    const selectedCategoryId = selectedCategory.getAttribute("data-category-id");
                    const hiddenInput = document.createElement("input");
                    hiddenInput.setAttribute("type", "hidden");
                    hiddenInput.setAttribute("name", "selected_category_id");
                    hiddenInput.setAttribute("value", selectedCategoryId);
                    addToCartForm.appendChild(hiddenInput);
                }
            });
        });
        </script>
    ';

    return $output;
}

add_shortcode('child_categories_dynamic', 'display_child_categories_with_details_shortcode_dynamic');

// Show selected category in the cart
function add_category_to_cart_item_data($cart_item_data, $product_id) {
    if (isset($_POST['selected_category_id'])) {
        $cart_item_data['selected_category_id'] = sanitize_text_field($_POST['selected_category_id']);
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'add_category_to_cart_item_data', 10, 2);

function display_selected_category_in_cart($item_data, $cart_item) {
    if (isset($cart_item['selected_category_id'])) {
        $term = get_term_by('id', $cart_item['selected_category_id'], 'product_cat');
        if ($term) {
            $item_data[] = array(
                'key'   => __('Selected Category'),
                'value' => $term->name,
            );
        }
    }
    return $item_data;
}
add_filter('woocommerce_get_item_data', 'display_selected_category_in_cart', 10, 2);

function add_selected_category_to_order_items($item, $cart_item_key, $values, $order) {
    if (isset($values['selected_category_id'])) {
        $term = get_term_by('id', $values['selected_category_id'], 'product_cat');
        if ($term) {
            $item->add_meta_data(__('Selected Category'), $term->name, true);
        }
    }
}
add_action('woocommerce_checkout_create_order_line_item', 'add_selected_category_to_order_items', 10, 4);


add_action( 'woocommerce_before_quantity_input_field', 'bbloomer_display_quantity_minus' );
 
function bbloomer_display_quantity_minus() {
   if ( ! is_product() ) return;
   echo '<button type="button" class="minus" >-</button>';
}
 
add_action( 'woocommerce_after_quantity_input_field', 'bbloomer_display_quantity_plus' );
 
function bbloomer_display_quantity_plus() {
   if ( ! is_product() ) return;
   echo '<button type="button" class="plus" >+</button>';
}
 
add_action( 'woocommerce_before_single_product', 'bbloomer_add_cart_quantity_plus_minus' );
 
function bbloomer_add_cart_quantity_plus_minus() {
   wc_enqueue_js( "
      $('form.cart').on( 'click', 'button.plus, button.minus', function() {
            var qty = $( this ).closest( 'form.cart' ).find( '.qty' );
            var val   = parseFloat(qty.val());
            var max = parseFloat(qty.attr( 'max' ));
            var min = parseFloat(qty.attr( 'min' ));
            var step = parseFloat(qty.attr( 'step' ));
            if ( $( this ).is( '.plus' ) ) {
               if ( max && ( max <= val ) ) {
                  qty.val( max );
               } else {
                  qty.val( val + step );
               }
            } else {
               if ( min && ( min >= val ) ) {
                  qty.val( min );
               } else if ( val > 1 ) {
                  qty.val( val - step );
               }
            }
         });
   " );
}


// Add the shortcode function
function display_related_products($atts) {
    // Ensure WooCommerce is active
    if (!class_exists('WooCommerce')) {
        return;
    }

    global $product;

    // Set default attributes and override with user attributes
    $atts = shortcode_atts(array(
        'limit' => 4, // Number of related products to display
    ), $atts, 'related_products');

    // Get related products
    $related_ids = wc_get_related_products($product->get_id(), $atts['limit']);
    
    if (empty($related_ids)) {
        return '<p>No related products found.</p>';
    }

    // Set up the query for related products
    $args = array(
        'post_type' => 'product',
        'post__in' => $related_ids,
        'posts_per_page' => $atts['limit'],
    );

    $related_query = new WP_Query($args);

    ob_start();

    if ($related_query->have_posts()) {
        echo '<ul class="related-products">';
        while ($related_query->have_posts()) : $related_query->the_post();
            global $product;
            ?>
<li class="product">
    <a href="<?php the_permalink(); ?>">
        <?php echo woocommerce_get_product_thumbnail(); ?>
        <h2 class="woocommerce-loop-product__title"><?php the_title(); ?></h2>
    </a>
    <?php
                // Display the review stars
                if (wc_get_rating_html($product->get_average_rating())) {
                    echo wc_get_rating_html($product->get_average_rating());
                }

                // Display the price
                echo '<span class="price">' . $product->get_price_html() . '</span>';

                // Display the add to cart button
                woocommerce_template_loop_add_to_cart();
                ?>
</li>
<?php
        endwhile;
        echo '</ul>';
    }

    wp_reset_postdata();

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('related_products', 'display_related_products');



function get_woocommerce_product($product_id) {
    $args = array(
        'include' => array( 144 ),
    );
    
    $products = wc_get_products( $args );
    
    foreach ($products as $product) {
        $saleproduct_id = $product->get_id(); 
        $sale_price = $product->get_sale_price();
        $regular_price = $product->get_regular_price();
        $sales_price_from = $product->get_date_on_sale_from();
        $sales_price_to = $product->get_date_on_sale_to();
        $new_price_from = $sales_price_from ? date('Y-m-d H:i:s', strtotime($sales_price_from)) : '';
        $new_price_to = $sales_price_to ? date('Y-m-d H:i:s', strtotime($sales_price_to)) : '';
        $sale_free = $sale_price > 0 ? $sale_price : 'Free';
        $image = wp_get_attachment_image_src(get_post_thumbnail_id($saleproduct_id), 'full');
    
        $html .= '<div class="sale-image-contant">';
        $html .= '<div class="sale-iamge">';
        $html .= '<div class="pro-image"><img src="' . $image[0] . '"></div></div>';
        $html .= '<div class="sale-contant"><div class="sale">Sale</div><div class="pro-title"><a href="' . get_permalink($saleproduct_id) . '">' . $product->get_name() . '</a></div>';
        $html .= '<div class="pro-short-des">' . $product->get_short_description() . '</div>';
        $html .= '<div class="pro-price"><div class="pro-sale-price">' . $sale_free . '</div><div class="pro-regular"><del>' . get_woocommerce_currency_symbol() . '' . $regular_price . '.00</del></div></div>';
        $html .= '<div id="countdown" data-end-date="' . $new_price_to . '"><div id="tiles"></div>';
        $html .= '</div>';
        $html .= '<div class="pro-info-btn"><div class="btn"><a href="' . get_permalink($saleproduct_id) . '" class="info-btn">MORE INFO</a></div></div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<input type="hidden" id="new_price_from" name="new_price_from" value="' . $new_price_from . '">';
        $html .= '<input type="hidden" id="new_price_to" name="new_price_to" value="' . $new_price_to . '">';
    }
    
    return $html; 
    
    }
    add_shortcode( 'single_product', 'get_woocommerce_product' );

  /* store locator customize code */
add_filter( 'wpsl_meta_box_fields', 'custom_meta_box_fields' );
function custom_meta_box_fields( $meta_fields ) {
    
    $meta_fields[__( 'Information', 'wpsl' )] = array(
        'mobile_number' => array(
            'label' => __( 'Mobile Numnber', 'wpsl' )
        ),
        'product_list' => array(
            'label' => __( 'Product List', 'wpsl' )
        ),
        'price_rate' => array(
            'label' => __( 'Price Rate', 'wpsl' )
        ),
        'coverage' => array(
            'label' => __( 'Coverage', 'wpsl' )
        ),
        'extended_coverage' => array(
            'label' => __( 'Extended Coverage', 'wpsl' )
        ),
        'minimum_order' => array(
            'label' => __( 'Minimum Order', 'wpsl' )
        ),
         'nursrey_pickup_address' => array(
            'label' => __( 'Nursrey Pickup Address', 'wpsl' )
        ),
          'nurserie_quantity_one' => array(
            'label' => __( 'Pricing 5 - 49 ', 'wpsl' )
        ),
          'nurserie_quantity_second' => array(
            'label' => __( 'Pricing 50 - 99 ', 'wpsl' )
        ),
          'nurserie_quantity_third' => array(
            'label' => __( 'Pricing 100 - 499 ', 'wpsl' )
        ),
          'nurserie_quantity_fourth' => array(
            'label' => __( 'Pricing 500 - 999 ', 'wpsl' )
        ),
         'nurserie_quantity_fifth' => array(
            'label' => __( 'Pricing 1000 + ', 'wpsl' )
        ),  
         'delivery_range' => array(
         'label' => __( 'Delivery Range', 'wpsl' )
        ),
         'nurserie_grower_notes' => array(
         'label' => __( 'Grower Notes', 'wpsl' )
        ),
         'nurserie_updated_inventory' => array(
         'label' => __( 'Updated Inventory', 'wpsl' )
        ), 
        'nurserie_order_confirmation' => array(
            'label' => __( 'Order Confirmation Text', 'wpsl' ),
            'type'  => 'wp_editor'
        ),
        'product_strain_listing' => array(
            'label' => __( 'Product Strain listing', 'wpsl' ),
            'type'  => 'wp_editor'
        ),
    );
    return $meta_fields;
}

add_filter( 'wpsl_templates', 'custom_templates' );

add_filter( 'wpsl_frontend_meta_fields', 'custom_frontend_meta_fields' );
function custom_frontend_meta_fields( $store_fields ) {

    $store_fields['wpsl_product_strain_listing'] = array( 
        'name' => 'product_strain_listing' 
    );
    $store_fields['wpsl_strain_menu'] = array( 
        'name' => 'strain_menu',
        'type' => 'url'
    );
    $store_fields['wpsl_price_list'] = array( 
        'name' => 'price_list',
        'type' => 'text'
    );
    $store_fields['wpsl_mobile_number'] = array( 
        'name' => 'mobile_number',
        'type' => 'number'
    );
    $store_fields['wpsl_product_list'] = array( 
        'name' => 'product_list',
        'type' => 'textarea'
    );
    $store_fields['wpsl_price_rate'] = array( 
        'name' => 'price_rate',
        'type' => 'textarea'
    );
    $store_fields['wpsl_coverage'] = array( 
        'name' => 'coverage',
        'type' => 'text'
    );
    $store_fields['wpsl_extended_coverage'] = array( 
        'name' => 'extended_coverage',
        'type' => 'text'
    ); 
     $store_fields['wpsl_minimum_order'] = array( 
        'name' => 'minimum_order',
        'type' => 'text'
    );
     $store_fields['wpsl_nursrey_pickup_address'] = array( 
        'name' => 'nursrey_pickup_address',
        'type' => 'text'
    );
     $store_fields['wpsl_nurserie_quantity_one'] = array( 
        'name' => 'nurserie_quantity_one',
        'type' => 'text'
    );
    $store_fields['wpsl_nurserie_quantity_second'] = array( 
        'name' => 'nurserie_quantity_second',
        'type' => 'text'
    );   
    $store_fields['wpsl_nurserie_quantity_third'] = array( 
        'name' => 'nurserie_quantity_third',
        'type' => 'text'
    );
    $store_fields['wpsl_nurserie_quantity_fourth'] = array( 
        'name' => 'nurserie_quantity_fourth',
        'type' => 'text'
    );
    $store_fields['wpsl_nurserie_quantity_fifth'] = array( 
        'name' => 'nurserie_quantity_fifth',
        'type' => 'text'
    );
    $store_fields['wpsl_nurserie_delivery_range'] = array( 
        'name' => 'delivery_range',
        'type' => 'text'
    );
    $store_fields['wpsl_nurserie_grower_notes'] = array( 
        'name' => 'nurserie_grower_notes',
        'type' => 'text'
    ); 
    $store_fields['wpsl_nurserie_updated_inventory'] = array( 
        'name' => 'nurserie_updated_inventory',
        'type' => 'text'
    );      
    $store_fields['wpsl_nurserie_order_confirmation'] = array( 
        'name' => 'nurserie_order_confirmation',
    );
    return $store_fields;
}

function wpsl_address_data() {

    global $wpsl_settings;

    $address_format = 'test';
  
    return $address_format;
}

function custom_templates( $templates ) {
    $templates[] = array (
        'id'   => 'custom',
        'name' => 'nurserie',
        'path' => get_stylesheet_directory() . '/public_html/wordpress/eighthsounces_new/wp-content/themes/twentytwentyfour-child/wpsl-templates/custom.php',
    );
    return $templates;
}
add_filter( 'wpsl_store_meta', 'custom_store_meta', 10, 2 );
function custom_store_meta( $store_meta, $store_id ) {

  $data = get_field_object('select_strain_products',$store_id);
  $product_lists = array();
  if ( count( $data['value'] ) > 1 ) {
    foreach($data['value'] as $term ) {     
      $permalink = get_permalink( $term->ID );
      $product_lists[] = '<p>' .$term->post_title. '</p>';
    }
    $store_meta['terms'] = implode( ' ', $product_lists );
  }else{
    $store_meta['terms'] = $terms[0]->name;
  }
  return $store_meta;
}

add_filter( 'wpsl_store_meta', 'sample_callback', 10, 2 );
function sample_callback($store_meta, $store_id) {
    
    $save_bookmark = array();
    $store_meta['save_book_mark']='';
    if(isset($_COOKIE['bookmarks'])){
       foreach($_COOKIE['bookmarks'] as $name => $value){
                    
            if($store_id == $value){
                $save_bookmark[]='true';
            }
        } 
    }
    $store_meta['save_book_mark'] = $save_bookmark; 
    return $store_meta;
}

add_filter( 'wpsl_store_meta', 'custom_store_meta_text', 10, 2 );
function custom_store_meta_text( $store_meta, $store_id ) {
    
    $confirm_text = get_field_object('order_confirmation_text', $store_id);
    $nursery_confirm_text = $confirm_text["value"];

    $img = get_field_object('nurseries_store_image', $store_id);
    $nursery_images = $img["value"];

    $store_meta['order_confirmation_text'] = $nursery_confirm_text;
    $store_meta['nurseries_store_image'] = $nursery_images;

    return $store_meta;
}

add_filter('wpsl_listing_template', 'custom_listing_template');
function custom_listing_template() {
    global $wpsl, $wpsl_settings;

    $more_info_url = '#';
    $listing_template = '<div id="overlay"><div class="cv-spinner"><span class="spinner"></span></div></div>';

    if ($wpsl_settings['template_id'] == 'default' && $wpsl_settings['more_info_location'] == 'info window') {
        $more_info_url = '#wpsl-search-wrap';
    }

    $listing_template .= '<li class="strain-store" data-store-id="<%= id %>">';
    $listing_template .= '
        <div id="wpsl-id-<%= _.escape(id) %>" class="wpsl-more-info-listings">
            <p class="coverage-details">
                <% if (typeof coverage !== "undefined") { %>
                    <span><strong>Coverage</strong>: <%= _.escape(coverage) %></span>
                <% } %>
                <% if (typeof extended_coverage !== "undefined") { %>
                    <span><strong>Extended Coverage</strong>: <%= _.escape(extended_coverage) %></span>
                <% } %>
                <% if (typeof minimum_order !== "undefined") { %>
                    <span><strong>Minimum Order</strong>: <%= _.escape(minimum_order) %></span>
                <% } %>
                <% if (typeof nurserie_updated_inventory !== "undefined") { %>
                    <span><strong>Updated Inventory</strong>: <a target="_blank" href="<%= _.escape(nurserie_updated_inventory) %>"><%= _.escape(nurserie_updated_inventory) %></a></span>
                <% } %>
                <% if (typeof delivery_range !== "undefined") { %>
                    <span><strong>Delivery Range</strong>: <%= _.escape(delivery_range) %></span>
                <% } %>
                <% if (typeof nurserie_grower_notes !== "undefined") { %>
                    <span><strong>Grower Notes</strong>: <%= _.escape(nurserie_grower_notes) %></span>
                <% } %>
                <% if (typeof order_confirmation_text !== "undefined") { %>
                    <span><strong>Order Confirmation Text</strong>: <%= _.escape(order_confirmation_text) %></span>
                <% } %>
                <% if (typeof terms !== "undefined") { %>
                    <div class="moreinfo-store-product-list"><%= _.escape(terms) %></div>
                <% } %>
                <% if (typeof nurseries_store_image !== "undefined") { %>
                    <div class="store-img"><%= nurseries_store_image %></div>
                <% } %>
            </p>
        </div>';

    $listing_template .= '
        <div class="wpsl-store-location">
            <div class="back-to-result"><i class="fas fa-arrow-left"></i> Back</div>
            <div class="nurseries-address">
                <span class="store-list #wpsl-id-<%= id %>" href="#wpsl-id-<%= id %>">
                    <div class="copy-nurseries-address">' . wpsl_store_header_template('listing') . '
                        <div class="city">
                            <h4><%= city %></h4> <h6><%= state %></h6>
                        </div>
                        <div class="wpsl-direction-wrap">';
    if (!$wpsl_settings['hide_distance']) {
        $listing_template .= '<%= distance %> ' . esc_html($wpsl_settings['distance_unit']) . '';
    }
    $listing_template .= '
                        </div>
                        <div class="clones_available">
                            <h6><strong>Clones Available :</strong> Yes</h6>
                        </div>
                        <div class="minimum_order">
                            <h6><strong>Minimum Clone Order :</strong> 5 Clones</h6>
                        </div>
                        <div class="teens_available">
                            <h6><strong>Teens Available :</strong> Yes</h6>
                        </div>
                        <div class="grow_medium">
                            <h6><strong>Minimum Teen Order :</strong> 3 Teens</h6>
                        </div>
                        <div class="delivery_available">
                            <h6><strong>Delivery Available :</strong> 100+ Clones</h6>
                        </div>
                    </div>
                </span>
            </div>
        </div>';

    $listing_template .= '
        <div class="right-button">
            <div class="btn-group">
                <div class="more-info btn-store green-btn-line">
                    <a class="btn-more-info" target="_blank" href="<%= permalink %>"> Available Strains</a>
                </div>
                <% if (save_book_mark == "true") { %>
                    <a class="btn-bookmark btn-save" href="javascript:void(0)" data-id="<%= id %>">Saved</a>
                <% } else { %>
                    <div class="more-info btn-store-line green-btn">
                        <button class="btn-more-info popmake-46468" data-name="<%= city %>">Contact Nursery</button>
                    </div>
                <% } %>
            </div>
             <div class="store-strain-details">
            <ul>
                <li>
                    <a data-fancybox class="starin_list" data-id="<%= id %>" href="#starin_list-<%= id %>">
                       <img src="http://jnextbeta.com/wordpress/eighthsounces_new/wp-content/uploads/2024/07/menu.svg">   Strains
                    </a>
                   <a data-fancybox class="starin_list" data-id="<%= id %>" href="#starin_list-<%= id %>">
                       <img src="http://jnextbeta.com/wordpress/eighthsounces_new/wp-content/uploads/2024/08/cash-app.svg">   Price 
                    </a>
                </li>';

    $listing_template .= '
                <% if (city == "Nationwide Shipping") { %>
                    <li class="test">
                        <a data-fancybox class="pricelist" data-id="<%= id %>" href="#pricelist-<%= id %>">
                            <i class="fa fa-dollar-sign" aria-hidden="true"></i>Price List
                        </a>
                        <div class="tabelview-fancybox" id="pricelist-<%= id %>" style="display:none">
                            <h3>Price List
                                <a class="copy-btn" href="#" onclick="CopyToClipboardcostprice(<%= id %>);return false;">
                                    <i class="far fa-copy"></i>
                                </a>
                            </h3>
                            <div class="price-list-box">
                                <div class="columnbox clearfix clones">
                                    <h4>For Clones</h4>
                                    <div class="inner-column four-column">
                                        <h5>Clones</h5>
                                        <ul>
                                            <li>3</li>
                                            <li class="price-list-genral">4-6</li>
                                            <li>7-11</li>
                                            <li>12-17</li>
                                            <li>18-23</li>
                                            <li>24-40</li>
                                            <li>41-50</li>
                                            <li>51-99</li>
                                            <li>100+</li>
                                        </ul>
                                    </div>
                                    <div class="inner-column four-column">
                                        <h5>Donation</h5>
                                        <ul>
                                            <li>$60/Ea</li>
                                            <li class="price-list-genral">$50/Ea</li>
                                            <li>$40/Ea</li>
                                            <li>$35/Ea</li>
                                            <li>$34/Ea</li>
                                            <li>$31/Ea</li>
                                            <li>$28/Ea</li>
                                            <li>$26/Ea</li>
                                            <li><a class="clone-link" href="../online-wholesale-order/">Get Quote</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="columnbox clearfix teens">
                                    <h4>For Teens</h4>
                                    <div class="inner-column four-column">
                                        <h5>Teens</h5>
                                        <ul>
                                            <li>1</li>
                                            <li>2</li>
                                            <li>3</li>
                                            <li>4-6</li>
                                            <li>7-11</li>
                                            <li>12+</li>
                                        </ul>
                                    </div>
                                    <div class="inner-column four-column">
                                        <h5>Donation</h5>
                                        <ul>
                                            <li>--</li>
                                            <li>--</li>
                                            <li>$100/Ea</li>
                                            <li>$95/Ea</li>
                                            <li>$85/Ea</li>
                                            <li>$75/Ea</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                <% } %>
            </ul>
        </div>
        </div>';

    $listing_template .= '
       
    </li>';

    return $listing_template;
}

function custom_product_filters_shortcode() {
    ob_start();      
    $categories = get_terms('product_cat', array('hide_empty' => true));
    
    // Fetch featured strains using ACF custom field
// Fetch categories
$categories = get_terms('product_cat', array('hide_empty' => true));

// Fetch featured strains using ACF custom field
$featured_strains_query = new WP_Query(array(
    'post_type' => 'product',
    'posts_per_page' => -1, // Adjust the number of posts as needed
    'meta_query' => array(
        array(
            'key' => 'featured_strains',
            'value' => 'yes',
            'compare' => 'LIKE'
        )
    )
));

$featured_strains = $featured_strains_query->posts;

    $types = get_terms('pa_type', array('hide_empty' => true));
    $child_categories = get_terms('product_cat', array('parent' => 0, 'hide_empty' => true));
    $seed_types = get_terms('pa_seeds', array('hide_empty' => true));
    $flavors = get_terms('pa_flavors', array('hide_empty' => true));
    $aromas = get_terms('pa_aromas', array('hide_empty' => true));
    $flower_time = get_terms('pa_flower_time', array('hide_empty' => true));
    $health_benefits = get_terms('pa_health_benefits', array('hide_empty' => true));
    $deals = get_posts(array('post_type' => 'product', 'meta_query' => array(array('key' => '_sale_price', 'value' => 0, 'compare' => '>'))));
    ?>
<div class="product-filters">
    <form method="GET" action="<?php echo esc_url(get_permalink(wc_get_page_id('seed'))); ?>">

        <!-- All Strains -->
        <div class="filter-category">
            <h4 class="filter-title" onclick="toggleFilter('all-strains-filters')">All Strains </h4>
            <div id="all-strains-filters" style="display:none;">
                <!-- Categories Subtitle -->
                <div class="filter-subtitle">
                    <div class="filter-subtitle-title" onclick="toggleFilter('category-filters')">Categories</div>
                    <ul id="category-filters" style="display:none;">
                        <?php foreach ($categories as $category): ?>
                        <li> <label><input type="checkbox" name="product_cat[]" value="<?php echo esc_attr($category->slug); ?>" /> <?php echo esc_html($category->name); ?>
                            </label>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Featured Strains Subtitle -->
                <div class="filter-subtitle">
                    <div class="filter-subtitle-title" onclick="toggleFilter('featured-strains-filters')">Featured Strains </div>
                    <ul id="featured-strains-filters" style="display:none;">
                        <?php foreach ($featured_strains as $strain): ?>
                        <li><label><input type="checkbox" name="featured_strains[]" value="<?php echo esc_attr($strain->ID); ?>" /><?php echo esc_html($strain->post_title); ?>
                            </label>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Type -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('type-filters')">Type</h4>
            <ul id="type-filters" style="display:none;">
                <?php foreach ($types as $type): ?>
                <li><label><input type="checkbox" name="pa_type[]" value="<?php echo esc_attr($type->slug); ?>" /><?php echo esc_html($type->name); ?></label>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Seeds -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('seeds-filters')">Seeds</h4>
            <ul id="seeds-filters" style="display:none;">
                <?php foreach ($child_categories as $child_category): ?>
                <li><label> <input type="checkbox" name="product_cat[]" value="<?php echo esc_attr($child_category->slug); ?>" /><?php echo esc_html($child_category->name); ?></label>
                </li>
                <?php endforeach; ?>
            </ul>
            <ul id="seeds-type-filters" style="display:none;">
                <?php foreach ($seed_types as $seed_type): ?> <li> <label> <input type="checkbox" name="pa_seeds[]" value="<?php echo esc_attr($seed_type->slug); ?>" /> <?php echo esc_html($seed_type->name); ?></label></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Flavors -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('flavors-filters')">Flavors</h4>
            <ul id="flavors-filters" style="display:none;">
                <?php foreach ($flavors as $flavor): ?>
                <li><label><input type="checkbox" name="pa_flavors[]" value="<?php echo esc_attr($flavor->slug); ?>" /> <?php echo esc_html($flavor->name); ?></label></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Aromas -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('aromas-filters')">Aromas</h4>
            <ul id="aromas-filters" style="display:none;">
                <?php foreach ($aromas as $aroma): ?>
                <li><label><input type="checkbox" name="pa_aromas[]" value="<?php echo esc_attr($aroma->slug); ?>" /> <?php echo esc_html($aroma->name); ?></label></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Flower Time -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('flower-time-filters')">Flower Time</h4>
            <ul id="flower-time-filters" style="display:none;">
                <?php foreach ($flower_time as $time): ?>
                <li><label><input type="checkbox" name="pa_flower_time[]" value="<?php echo esc_attr($time->slug); ?>" /> <?php echo esc_html($time->name); ?></label>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Health Benefits -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('health-benefits-filters')">Health Benefits</h4>
            <ul id="health-benefits-filters" style="display:none;">
                <?php foreach ($health_benefits as $benefit): ?>
                <li><label><input type="checkbox" name="pa_health_benefits[]" value="<?php echo esc_attr($benefit->slug); ?>" /> <?php echo esc_html($benefit->name); ?></label>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Deals -->
        <div class="filter-attribute">
            <h4 onclick="toggleFilter('deals-filters')">Deals</h4>
            <ul id="deals-filters" style="display:none;">
                <?php foreach ($deals as $deal): ?>
                <li><label> <input type="checkbox" name="deals[]" value="<?php echo esc_attr($deal->ID); ?>" /> <?php echo esc_html($deal->post_title); ?></label>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Price -->
        <div class="filter-price">
            <h4 onclick="toggleFilter('price-filters')">Price</h4>
            <ul id="price-filters" style="display:none;">
                <li>
                    <label><input type="checkbox" name="price_range" value="under_20" /> Under $20</label>
                </li>
                <li>
                    <label><input type="checkbox" name="price_range" value="20_40" /> $20 - $40</label>
                </li>
                <li>
                    <label><input type="checkbox" name="price_range" value="40_60" /> $40 - $60</label>
                </li>
                <li>
                    <label><input type="checkbox" name="price_range" value="60_80" /> $60 - $80</label>
                </li>
                <li>
                    <label><input type="checkbox" name="price_range" value="80_above" /> $80 & above</label>
                </li>
            </ul>
        </div>

        <button type="submit">Apply</button>
    </form>
</div>

<script>
function toggleFilter(id) {
    var element = document.getElementById(id);
    if (element.style.display === "none") {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
</script>

<?php
    return ob_get_clean();  
}

add_shortcode('custom_product_filters', 'custom_product_filters_shortcode');


function filter_products_query($query) {
    if (!is_admin() && $query->is_main_query() && is_post_type_archive('product')) {
        // Filter by category
        if (!empty($_GET['product_cat'])) {
            $query->set('tax_query', array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $_GET['product_cat']
                )
            ));
        }
        
        
        if (!empty($_GET['featured_strains'])) {
            $meta_query = $query->get('meta_query');
            $meta_query[] = array(
                'key' => 'featured_strains',
                'value' => 'yes',
                'compare' => 'LIKE'
            );
            $query->set('meta_query', $meta_query);
        }

        // Add other filters as needed...
    }
}
add_action('pre_get_posts', 'filter_products_query');






function logo_slider_shortcode() {
    // Define the image URLs here - adjust the path as per your setup
    $images = array(
        get_stylesheet_directory_uri() . '/img/image118.svg',
        get_stylesheet_directory_uri() . '/img/image119.svg',
        get_stylesheet_directory_uri() . '/img/image120.svg',
        get_stylesheet_directory_uri() . '/img/image121.svg',
        get_stylesheet_directory_uri() . '/img/image122.svg'
    );

    ob_start();
    ?>
<div class="logo-img-slider">
    <div class="swiper-wrapper">
        <?php foreach ($images as $image): ?>
        <div class="swiper-slide"><img src="<?php echo esc_url($image); ?>" alt="Slide Image"></div>
        <?php endforeach; ?>
    </div>
</div>
<?php
    return ob_get_clean();
}

add_shortcode('logo_swiper_slider', 'logo_slider_shortcode');


function display_shipping_methods() {
    ob_start();
    ?>
    <div class="shipping-method-selection">
        <ul id="shipping-method" class="shipping-method-list">
            <li data-method="ship_my_order" class="selected">
                <h4>Ship My Order</h4>
                <p class="green-text">SHIPPING INCLUDED</p>
            </li>
            <li data-method="schedule_pickup">
                <h4>Schedule Pickup</h4>
                <p>Schedule your pickup or delivery after checkout.</p>
            </li>
            <li data-method="delivery">
                <h4>Delivery</h4>
                <p>Delivery fees may apply based on location and order size.</p>
            </li>
        </ul>
    </div>
    <script>
        jQuery(document).ready(function($) {
            // Set the default selected shipping method
            var selectedMethod = "ship_my_order";
            $("#shipping-method li").each(function() {
                if ($(this).data("method") == selectedMethod) {
                    $(this).addClass("selected");
                } else {
                    $(this).removeClass("selected");
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('shipping_methods', 'display_shipping_methods');

function display_shipping_methods_location() {
    ob_start();
    ?>
    <div class="shipping-method-selection">
        <ul id="shipping-method" class="shipping-method-list">
            <li data-method="ship_my_order" class="selected">
                <h4>Ship My Order</h4>
                <p class="green-text">SHIPPING INCLUDED</p>
            </li>
        </ul>
    </div>
    <script>
        jQuery(document).ready(function($) {
            // Set the default selected shipping method
            var selectedMethod = "ship_my_order";
            $("#shipping-method li").each(function() {
                if ($(this).data("method") == selectedMethod) {
                    $(this).addClass("selected");
                } else {
                    $(this).removeClass("selected");
                }
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('shipping_methods_location', 'display_shipping_methods_location');

function show_shipping_methods_before_add_to_cart() {
    $product_id = get_the_ID();
    $city_terms = get_the_terms($product_id, 'city');
    if (has_term('strain', 'product_cat', $product_id)) {
        echo do_shortcode('[shipping_methods]');
    }
    if ($city_terms && !is_wp_error($city_terms)) {
        echo do_shortcode('[shipping_methods_location]');
    }
}
add_action('woocommerce_before_add_to_cart_form', 'show_shipping_methods_before_add_to_cart');



function add_shipping_method_to_cart_item_data($cart_item_data, $product_id, $variation_id) {
    if (isset($_POST['shipping_method'])) {
        $cart_item_data['shipping_method'] = sanitize_text_field($_POST['shipping_method']);
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'add_shipping_method_to_cart_item_data', 10, 3);

// Display the shipping method in the cart
function display_shipping_method_in_cart($item_data, $cart_item) {
    if (isset($cart_item['shipping_method'])) {
        $item_data[] = array(
            'name' => 'Shipping Method',
            'value' => $cart_item['shipping_method']
        );
    }
    return $item_data;
}
add_filter('woocommerce_get_item_data', 'display_shipping_method_in_cart', 10, 2);

// Save the shipping method to the order
function save_shipping_method_to_order($item, $cart_item_key, $values, $order) {
    if (isset($values['shipping_method'])) {
        $item->add_meta_data('Shipping Method', $values['shipping_method'], true);
    }
}
add_action('woocommerce_checkout_create_order_line_item', 'save_shipping_method_to_order', 10, 4);

// Modify URL construction to remove commas
function show_state_city_list($atts) {
    $output = '';

    // Get the current post ID
    $post_id = get_the_ID();

    // Retrieve the state meta value for the current post
    $state = get_post_meta($post_id, 'wpsl_state', true);

    if (!empty($state)) {
        // Query to get all store IDs in the specified state
        $args = array(
            'post_type'      => 'wpsl_stores',
            'posts_per_page' => -1, // Retrieve all posts
            'meta_query'     => array(
                array(
                    'key'   => 'wpsl_state',
                    'value' => $state,
                ),
            ),
        );

        $stores_query = new WP_Query($args);

        if ($stores_query->have_posts()) {
            // Start output with grid container
            $output .= '<div class="store-grid-container">';
        
            while ($stores_query->have_posts()) {
                $stores_query->the_post();
        
                // Get city name for each store
                $city = get_post_meta(get_the_ID(), 'wpsl_city', true);
        
                // Get map URL for each store
                $map_url = get_post_meta(get_the_ID(), 'city_map', true);
        
                // Start grid item
                $output .= '<div class="store-grid-item">';
                if (!empty($map_url)) {
                    $output .= '<iframe src="' . esc_url($map_url) . '" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
                }
                $output .= '<h4>Clones for sale in ' . esc_html($city) . '</h4>';
                $output .= '<p>Available: Clones, Teens, & Shipping</p>';
                $output .= '<div class="button-wrap green-btn-line btn-store btn-store-line green-btn">';
                
                // Add city URL to the View Strains button, removing commas
                $city_sanitized = str_replace(',', '', $city); // Remove commas from the city name
                $city_url = site_url('city') . '?city=' . urlencode($city_sanitized); 
                $output .= '<a href="' . esc_url($city_url) . '" class="button">View Strains</a> ';
                $output .= '<a href="#" class="button">Contact Us</a>';
                $output .= '</div>';
                $output .= '</div>'; // End grid item
            }
        
            // End output
            $output .= '</div>'; // End grid container
        
            // Restore original post data
            wp_reset_postdata();
        } else {
            $output = __('No stores found in the specified state.', 'wpsl');
        }
        
    } else {
        $output = __('State not specified.', 'wpsl');
    }

    return $output;
}

// Register the shortcode
add_shortcode('wpsl_state_city_list', 'show_state_city_list');


function show_city_products($atts) {
    $output = '';

    // Set up the query arguments
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => 9,
    );

    if (isset($_GET['city']) && !empty($_GET['city'])) {
        $city = sanitize_text_field($_GET['city']);
        $term_city = get_term_by('name', $city, 'city');
        if ($term_city) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'city',
                    'field'    => 'term_id',
                    'terms'    => $term_city->term_id,
                ),
            );
        }
    }

    $products_query = new WP_Query($args);

    if ($products_query->have_posts()) {
        // Start output
        $output .= '<ul class="products todays-recommendations city-product">';

        while ($products_query->have_posts()) {
            $products_query->the_post();
            global $product;
            $product_id = get_the_ID();
            $product_title = get_the_title();
            $product_link = get_permalink();
            $product_image = wp_get_attachment_image_src(get_post_thumbnail_id($product_id), 'single-post-thumbnail')[0];
            $thc = get_field('thc', $product_id);
            $cbd = get_field('cbd', $product_id);
            $type = get_field('type', $product_id);
            $flower_time = get_field('flower_time', $product_id);

            $output .= '<li class="product">';
            $output .= '<div class="product-top-right">';
            $output .= '<a href="?add-to-cart=' . $product_id . '&redirect_to_cart=1" class="add-to-cart"><img src="' . esc_url(get_stylesheet_directory_uri() . '/img/heard.svg') . '" alt="Add to Cart"></a>';
            $output .= '</div>';
            $output .= '<a href="' . esc_url($product_link) . '">';
            $output .= '<img class="city-product-img" src="' . esc_url($product_image) . '" alt="' . esc_attr($product_title) . '">';
            $output .= '<h2>' . esc_html($product_title) . '</h2>';
            $output .= '</a>';
            $output .= '<div class="product-wrap">';
            $output .= '<div class="product-details">';
            $output .= '<div class="product-thc-cbd">';
            $output .= '<p><strong>THC:</strong> ' . esc_html($thc) . '</p>';
            $output .= '<p><strong>CBD:</strong> ' . esc_html($cbd) . '</p>';
            $output .= '</div>';
            $output .= '<div class="product-type-flower">';
            $output .= '<p><strong>Type:</strong> ' . esc_html($type) . '</p>';
            $output .= '<p><strong>Flower Time:</strong> ' . esc_html($flower_time) . '</p>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '<a href="' . esc_url($product_link) . '" class="button">View Product</a>';
            $output .= '</div>';
            $output .= '</li>';
        }
        $output .= '</ul>';

        // Restore original post data
        wp_reset_postdata();
    } else {
        $output = __('No products found for the specified city.', 'wpsl');
    }

    return $output;
}

add_shortcode('city_products', 'show_city_products');

add_action('template_redirect', 'redirect_to_cart_after_adding');

function redirect_to_cart_after_adding() {
    if (isset($_GET['add-to-cart']) && isset($_GET['redirect_to_cart']) && $_GET['redirect_to_cart'] == 1) {
        wp_redirect(wc_get_cart_url());
        exit;
    }
}


// Register the shortcode
function display_city_info_shortcode() {
    // Get the repeater field values
    if (isset($_GET['city']) && !empty($_GET['city'])) {
        $city = sanitize_text_field($_GET['city']);
        $term_city = get_term_by('name', $city, 'city');
        
        $city_info = get_field('table_content', 'term_'. $term_city->term_id);
        
        ob_start();

        if( $city_info ) {
            echo '<div class="tab_list_wrap">';
            echo '<ul class="tab_lists">';
            foreach( $city_info as $key => $row ) {
                $city_name = $row['table_title'];
                echo '<li class="tab_list" data-id="'. $key .'">' . esc_html( $city_name ) . '</li>';
            }
            echo '</ul>';
            
            foreach( $city_info as $key => $row ) {
                echo '<div class="tab_content" id="tab-content-'. $key .'">';
                echo $row['table_details'];
                echo '</div>';
            }
            echo '</div>';
        } else {
            
        }
        
    }else{
       
    }
    return ob_get_clean();
}

// Register the shortcode with WordPress
add_shortcode('city_info', 'display_city_info_shortcode');




// Shortcode to display ACF repeater field with Swiper.js
function acf_slider_shortcode() {
    ob_start();
    // Fetch the repeater field
    if ( have_rows( 'slider' ) ) :
        ?>
        <div class="home-slider swiper-container">
            <div class="swiper-wrapper">
                <?php
                // Loop through the rows of data
                while ( have_rows( 'slider' ) ) : the_row();
                    $slider_img = get_sub_field( 'slider_img' );
                    $slider_img_2 = get_sub_field( 'slider_img_2' );
                    $slider_img_3 = get_sub_field( 'slider_img_3' );
                    $slider_img_4 = get_sub_field( 'slider_img_4' );
                    $slider_img_5 = get_sub_field( 'slider_img_5' );
                    $slider_title = get_sub_field( 'slider_title' );
                    $slider_subtitle = get_sub_field( 'slider_subtitle' );
                    $shop_button = get_sub_field( 'shop_button' );
                    $note = get_sub_field( 'note' );
                    ?>
                    <div class="swiper-slide">
                        <div class="slider-wrap">
                            <div class="slider-content-group">
                                <?php if ( $slider_title ) : ?>
                                    <h2><?php echo esc_html( $slider_title ); ?></h2>
                                <?php endif; ?>
                                <?php if ( $slider_subtitle ) : ?>
                                    <p><?php echo esc_html( $slider_subtitle ); ?></p>
                                <?php endif; ?>
                                <?php if ( $shop_button ) : ?>
                                    <a href="<?php echo esc_url( $shop_button ); ?>" class="shop-button">Shop Now</a>
                                <?php endif; ?>
                                <?php if ( $note ) : ?>
                                    <p class="note"><?php echo esc_html( $note ); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="slider-img-group">
                                <?php if ( $slider_img ) : ?>
                                    <a href="#"><img src="<?php echo $slider_img; ?>"  /></a>
                                <?php endif; ?>
                            </div>
                            <div class="slider-img-2-group slider-flex">
                                <?php if ( $slider_img_2 ) : ?>
                                   <a href="#"> <img src="<?php echo $slider_img_2; ?>" /></a>
                                <?php endif; ?>
                                <?php if ( $slider_img_3 ) : ?>
                                    <a href="#"><img src="<?php echo $slider_img_3; ?>" /></a>
                                <?php endif; ?>
                                <?php if ( $slider_img_4 ) : ?>
                                    <a href="#"> <img src="<?php echo $slider_img_4; ?>" /></a>
                                <?php endif; ?>
                                <?php if ( $slider_img_5 ) : ?>
                                    <a href="#"> <img src="<?php echo $slider_img_5; ?>" /></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                endwhile;
                ?>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
            <!-- Add Navigation -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <?php
    endif;
    return ob_get_clean();
}
add_shortcode( 'acf_slider', 'acf_slider_shortcode' );

// Start the session to track user activity
if (!function_exists('custom_start_wc_session')) {
    add_action('init', 'custom_start_wc_session', 1);
    function custom_start_wc_session() {
        if (!session_id()) {
            session_start();
        }
    }
}

// Track viewed products
add_action('template_redirect', 'custom_track_product_view');
function custom_track_product_view() {
    if (is_singular('product')) {
        global $post;

        if (!isset($_SESSION['custom_recently_viewed_products'])) {
            $_SESSION['custom_recently_viewed_products'] = array();
        }

        $recently_viewed = $_SESSION['custom_recently_viewed_products'];
        $product_id = $post->ID;

        if (!in_array($product_id, $recently_viewed)) {
            $recently_viewed[] = $product_id;
            $_SESSION['custom_recently_viewed_products'] = $recently_viewed;
        }
    }
}

// Create the shortcode to display recently viewed products with Swiper slider
if (!function_exists('custom_recently_viewed_products_shortcode')) {
    add_shortcode('custom_recently_viewed_products_home', 'custom_recently_viewed_products_shortcode');
    function custom_recently_viewed_products_shortcode($atts) {
        if (empty($_SESSION['custom_recently_viewed_products'])) {
            return '<div class="no-recently-viewed-products">
                        <h2>No recently viewed products</h2>
                        <p>Get back to shopping - check out our weekly ad for the latest sales.</p>
                    </div>';
        }

        $recently_viewed = $_SESSION['custom_recently_viewed_products'];

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            'post__in' => $recently_viewed,
            'orderby' => 'post__in'
        );

        $query = new WP_Query($args);

        if (!$query->have_posts()) {
            return '<div class="no-recently-viewed-products">
                        <h2>No recently viewed products</h2>
                        <p>Get back to shopping - check out our <a href="/weekly-ad">weekly ad</a> for the latest sales.</p>
                    </div>';
        }

        ob_start();

        echo '<div class="recentview-container-home swiper-container">';
        echo '<div class="swiper-wrapper">';

        while ($query->have_posts()) : $query->the_post();
            global $product;

            echo '<div class="swiper-slide">';
            echo '<li>';
            echo '<a href="' . get_permalink() . '">';
            echo woocommerce_get_product_thumbnail(); // Product image
            echo '</a>';
            echo '<h2 class="woocommerce-loop-product__title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
            echo '</li>';
            echo '</div>';

        endwhile;

        echo '</div>'; // .swiper-wrapper
        echo '</div>'; // .swiper-container

        wp_reset_postdata();

        return ob_get_clean();
    }
}


// Register the shortcode
function display_faqs_shortcode($atts) {

    $product_id = get_the_id();

    // Get the product categories based on the product ID
    $product_categories = get_the_terms($product_id, 'product_cat');
    $product_categories_slugs = array();

    if ($product_categories && !is_wp_error($product_categories)) {
        foreach ($product_categories as $category) {
            $product_categories_slugs[] = $category->slug;
        }
    }

    // Query FAQ posts
    $args = array(
        'post_type' => 'faq',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'faq_categories',
                'value' => $product_categories_slugs,
                'compare' => '=',
            ),
        ),
    );

    $faq_query = new WP_Query($args);
    
    ob_start();

    if ($faq_query->have_posts()) {
        $counter = 0;
        echo '<div class="faqs">';

        while ($faq_query->have_posts()) {
            $faq_query->the_post();

            if ($counter % 2 == 0) {
                if ($counter > 0) {
                    echo '</div>'; // Close the previous main div
                }
                echo '<div class="faq-pair">';
            }

            // Use the provided image URL inside the <h2> tag
            $image_html = '<img src="http://jnextbeta.com/wordpress/eighthsounces_new/wp-content/uploads/2024/07/Question.png" alt="Question Icon" style="vertical-align: middle; margin-right: 5px;">';

            echo '<div class="faq">';
            echo '<h2>' . $image_html . get_the_title() . '</h2>';
            echo '<div class="faq-description">' . get_the_content() . '</div>';
            echo '</div>';

            $counter++;
        }

        echo '</div>'; // Close the last main div
        echo '</div>'; // Close the faqs wrapper

        if ($counter > 8) {
            echo '<button id="see-more-faqs">See More</button>';
        }
    } else {
        echo '<p>No FAQs found.</p>';
    }

    wp_reset_postdata();

    ?>
    <script type="text/javascript">
        (function($) {
            var totalFaqs = <?php echo $counter; ?>;
            var visibleFaqs = 8;
            $('#see-more-faqs').click(function() {
                $('.faq-pair').slice(visibleFaqs / 2, visibleFaqs / 2 + 2).slideDown();
                visibleFaqs += 8;
                if (visibleFaqs >= totalFaqs) {
                    $(this).hide();
                }
            });
            $(document).ready(function() {
                $('.faq-pair').slice(8 / 2).hide();
            });
        })(jQuery);
    </script>
    <?php

    return ob_get_clean();
}

add_shortcode('display_faqs', 'display_faqs_shortcode');


// Shortcode to display the review count and average rating of the current product
function display_current_product_review_info() {
    if ( ! is_product() ) {
        return 'This shortcode can only be used on product pages.';
    }

    global $product;

    if ( ! $product ) {
        return 'Product not found.';
    }

    // Get the review count and average rating
    $review_count = $product->get_review_count();
    $average_rating = $product->get_average_rating();

    // Generate the star icons
    $star_rating_html = wc_get_rating_html( $average_rating );

    // Format the output
    $output = sprintf(
        '<div class="product-review-info">
            <div class="star-rating">%s</div>
            <div class="review-text"> %.1f out of 5 (%d reviews)</div>
        </div>',
        $star_rating_html,
        $average_rating,
        $review_count
    );

    return $output;
}
add_shortcode( 'current_product_review_info', 'display_current_product_review_info' );


function count_faqs_by_category() {
    if (!is_singular('product')) {
        return '';
    }

    global $post;
    $product_categories = get_the_terms($post->ID, 'product_cat');
    if (empty($product_categories) || is_wp_error($product_categories)) {
        return '';
    }

    $product_category_slugs = wp_list_pluck($product_categories, 'slug');
    
    $args = array(
        'post_type' => 'faq',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'faq_categories',
                'value' => $product_category_slugs,
                'compare' => '='
            )
        )
    );

    $faq_query = new WP_Query($args);
    $faq_count = $faq_query->found_posts;

    return '<div class="faq-count">(' . $faq_count . ') Questions & Answers</div>';
}

add_shortcode('faq_count', 'count_faqs_by_category');



/*Export product  Code*/

function custom_export_woocommerce_products_clean() {
    global $wpdb;

    if (ob_get_contents()) ob_end_clean();

    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=products_export_" . date('Y-m-d') . ".csv");
    header("Pragma: no-cache");
    header("Expires: 0");

    $output = fopen('php://output', 'w');

    $args = [
        'post_type' => 'product',
        'posts_per_page' => 1,
        'post_status' => 'publish',
    ];
    $products = get_posts($args);

    $meta_keys = [];
    $meta_keys_title = [];
    $variation_meta_keys = [];
    foreach ($products as $key => $product) {
        
        $product_data = wc_get_product($product->ID);
        $product_meta_keys = get_post_meta($product->ID);
        $filtered_meta_data = array_filter($product_meta_keys, function($key) {
            return !(strpos($key, '_') === 0);
        }, ARRAY_FILTER_USE_KEY);
        
        $meta_keys = array_merge($meta_keys, array_keys($filtered_meta_data));
        
        $filtered_meta_data_with_prefix = array_map(function($key) {
            return 'meta_' . $key;
        }, $meta_keys);
        
        $meta_keys_title = array_merge($meta_keys_title, $filtered_meta_data_with_prefix);
        
        if ($product_data->is_type('variable')) {
            $variations = $product_data->get_children();
            foreach ($variations as $variation_id) {
                $variation_meta_keys[] = array_keys(get_post_meta($variation_id));
            }
        }

    }
    
    $meta_keys = array_unique($meta_keys);
    $meta_keys_title = array_unique($filtered_meta_data_with_prefix);
    
    $taxonomy_keys = array();
    $taxonomy_title_keys = array();
    $taxonomies = get_object_taxonomies('product', 'object');
    
    foreach ($taxonomies as $taxonomy_slug => $taxonomy) { 
        if( !in_array( $taxonomy->name, $taxonomy_keys ) ){
            array_push( $taxonomy_keys, $taxonomy->name );
            array_push( $taxonomy_title_keys, 'tax_'.$taxonomy->name );
        }
        
    }
    $headers = array_merge(['ID', 'Title', 'Slug', 'Content', 'Excerpt', 'Short Description', 'Status', 'SKU', 'Price', 'Author', 'Product Category', 'Product Thumbnail', 'Product gallery', 'Product Type', 'Menu Order'], $meta_keys_title, $taxonomy_title_keys, ['Attributes', 'Variations']);
    
    fputcsv($output, $headers);
    
    foreach ($products as $product) {
        
        $product_data = wc_get_product($product->ID);
        $category_ids = array();
        if ( $product_data instanceof WC_Product ) {
            
            $terms = get_the_terms( $product_data->get_id(), 'product_cat' );
            
            if ( !empty($terms) && !is_wp_error($terms) ) {
                foreach ( $terms as $term ) {
                    $category_ids[] = $term->term_id;
                }
            }
            
        }
        $categories = export_categories_to_csv_based_on_ids($category_ids);
        
        $gallery_images = array();
        
        if( !empty( $product_data->get_gallery_image_ids() ) ){ 
            foreach( $product_data->get_gallery_image_ids() as $gallery_ids ){ 
                $gallery_images[] = wp_get_attachment_url($gallery_ids);
            }
        }
        
        $row = [
            $product->ID,
            $product->post_title,
            $product->post_name,
            $product->post_content,
            $product->post_excerpt,
            $product_data->get_short_description(),
            $product->post_status,
            $product_data->get_sku(),
            $product_data->get_price(),
            $product->post_author,
            !empty($categories) ? json_encode($categories) : '',
            wp_get_attachment_url($product_data->get_image_id()),
            !empty( $gallery_images ) ? json_encode($gallery_images) : '',
            $product_data->get_type(),
            $product->menu_order,
        ];

        foreach ($meta_keys as $meta_key) {
            
            
            if( $meta_key == 'typical_effects' || $meta_key == 'common_usage' || $meta_key == 'flavors' || $meta_key == 'aromas' || $meta_key == 'store_city' ){
                
                $meta_taxonomies = get_field($meta_key, $product->ID);
                
                if( !empty( $meta_taxonomies ) ){
                    $meta_tax = array();
                    foreach( $meta_taxonomies as $tax ){
                        $meta_tax[] = $tax->name;
                    }
                }
                $meta_value = $meta_tax;
                
            }else{
                
                $meta_value = get_post_meta($product->ID, $meta_key, true);
                
            }
            
            $row[] = is_array($meta_value) ? json_encode($meta_value) : $meta_value;
        }
        
        foreach( $taxonomy_keys as $meta_key ){
            
            $terms = get_the_terms($product_data->get_id(), $meta_key);
            
            $taxonomy_value = array();
            if( !empty( $terms ) ){
                foreach( $terms as $term ){
                    $taxonomy_value[] = $term->name;        
                }
            }
            
            $row[] = ( is_array($taxonomy_value) && !empty( $taxonomy_value ) ) ? json_encode($taxonomy_value) : '';
            
        }
        
        $variations_data = [];
        if ($product_data->is_type('variable')) {
            $variations = $product_data->get_children();
            foreach ($variations as $variation_key => $variation_id) {
                $variation_data = wc_get_product($variation_id);
                $variation_meta = [];
                foreach ($variation_meta_keys[$variation_key] as $meta_key) { 
                    $variation_meta[$meta_key] = ( !empty(get_post_meta($variation_id, $meta_key, true)) ) ? get_post_meta($variation_id, $meta_key, true) : '';
                }
                
                $variations_data[] = [
                    'id' => $variation_id,
                    'sku' => $variation_data->get_sku(),
                    'price' => $variation_data->get_price(),
                    'parent_id' => $variation_data->get_parent_id(),
                    'meta' => $variation_meta,
                ];
            }
        }
        
        $attributes = array();
        if( !empty($product_data->get_attributes()) ){
            foreach ($product_data->get_attributes() as $attribute) {
                if ( $attribute instanceof WC_Product_Attribute ) {
                    $attribute_name = $attribute['name'];
                    $attribute_values = $attribute['value'];
                    
                    $attributes[$attribute_name] = array(
                        'values' => $attribute_values,
                        'visible' => $attribute->get_data()['is_visible'],
                        'variation' => $attribute->get_data()['is_variation']
                    );
                }
            }
        }
        $row[] = json_encode( $attributes );
        $row[] = json_encode( $variations_data );
        
        
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// Add a custom admin menu item for export
function custom_export_menu_clean() {
    add_menu_page(
        'Export WooCommerce Products',
        'Export Products',
        'manage_options',
        'custom-export-products-clean',
        'custom_export_woocommerce_products_clean'
    );
}
add_action('admin_menu', 'custom_export_menu_clean');


/*Import Code*/
function custom_import_woocommerce_products_clean() {
    if (!class_exists('WooCommerce') || !class_exists('ACF')) {
        return;
    }
    global $wpdb;
    if (isset($_FILES['import_csv']) && $_FILES['import_csv']['error'] == 0) {
        $file = $_FILES['import_csv']['tmp_name'];

        if (($handle = fopen($file, 'r')) !== false) {
            
            $header = fgetcsv($handle);
            
            $meta_keys = array();
            $taxonomy_keys = array();
            $product_id_i = -1;
            $title_i = $slug_i = $content_i = $excerpt_i = $short_desc_i = $status_i = $sku_i = $price_i = $author_i = $cat_i = $thumbnail_i = $gallery_i = $type_i = $menu_order_i = $attribute_i = $variation_i = 0;
            
            foreach ($header as $header_id => $key) {
                
                if (strpos($key, 'meta_') === 0) {
                    $meta_keys[$header_id] = str_replace('meta_', '', $key);
                } elseif (strpos($key, 'tax_') === 0) {
                    $taxonomy_keys[$header_id] = str_replace('tax_', '', $key);
                }
                
                if( $key === 'ID' || $key === 'id' ){
                    $product_id_i = $header_id;
                }
                
                if( $key === 'Title' || $key === 'title' ){
                    $title_i = $header_id;
                }
                if( $key === 'Slug' || $key === 'slug' ){
                    $slug_i = $header_id;
                }
                if( $key === 'Content' || $key === 'content' ){
                    $content_i = $header_id;
                }
                if( $key === 'Excerpt' || $key === 'excerpt' ){
                    $excerpt_i = $header_id;
                }
                if( $key === 'Short Description' || $key === 'short description' || $key === 'short_description' || $kley === 'short_desc' ){
                    $short_desc_i = $header_id;
                }
                if( $key === 'Status' || $key === 'status' ){
                    $status_i = $header_id;
                }
                if( $key === 'SKU' || $key === 'sku' ){
                    $sku_i = $header_id;
                }
                if( $key === 'Price' || $key === 'price' ){
                    $price_i = $header_id;
                }
                if( $key === 'Author' || $key === 'author' ){
                    $author_i = $header_id;
                }
                if( $key === 'Product Category' || $key === 'product category' ){
                    $cat_i = $header_id;
                }
                if( $key === 'Product Thumbnail' || $key === 'product thumbnail' ){
                    $thumbnail_i = $header_id;
                }
                if( $key === 'Product gallery' || $key === 'product gallery' ){
                    $gallery_i = $header_id;
                }
                if( $key === 'Product Type' || $key === 'product type' ){
                    $type_i = $header_id;
                }
                if( $key === 'Menu Order' || $key === 'menu order' ){
                    $menu_order_i = $header_id;
                }
                if( $key === 'Attributes' || $key === 'attributes' ){
                    $attribute_i = $header_id;
                }
                if( $key === 'Variations' || $key === 'variations' ){
                    $variation_i = $header_id;
                }
                
            }
                
            while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                
                if( -1 != $product_id_i ){
                	$existing_post = get_post($data[$product_id_i]); 
                    if ($existing_post) {
                        wp_delete_post($data[$product_id_i], true);
                    }
                    $product_data = array(
                        'ID'          => $data[$product_id_i],
                        'post_content'=> $data[$content_i],
                        'post_title'  => $data[$title_i],
                        'post_excerpt'=> $data[$excerpt_i],
                        'post_status' => $data[$status_i],
                        'post_type'   => 'product',
                    );
                    $wpdb->insert( $wpdb->prefix.'posts', $product_data );
                    $post_id = $wpdb->insert_id;
                    if( $post_id ){
                        if( $data[$type_i] == 'simple' ){
                            
                            wp_set_object_terms($post_id, 'simple', 'product_type');
                            $product = new WC_Product_Simple($post_id);
                            
                        }else if( $data[$type_i] == 'variable' ){
                            
                            wp_set_object_terms($post_id, 'variable', 'product_type');
                            $product = new WC_Product_Variable($post_id);
                            
                        }
                        if( $product ){
                            if( !empty( $data[$title_i] ) ){
                                $product->set_name( $data[$title_i] );
                            }
                            
                            if( !empty( $data[$slug_i] ) ){
                                $product->set_slug( $data[$slug_i] );
                            }
                            
                            if( !empty( $data[$content_i] ) ){
                                $product->set_description($data[$content_i]);
                            }
                            
                            if( !empty( $data[$short_desc_i] ) ){
                                $product->set_short_description($data[$short_desc_i]);
                            }
                            
                            if( !empty( $data[$sku_i] ) ){
                                $product->set_sku($data[$sku_i]);
                            }
                            
                            /*if( !empty( $data[$status_i] ) ){
                                $product->set_status($data[$status_i]);
                            }*/
                            
                            if( !empty( $data[$price_i] ) ){
                                $product->set_price($data[$price_i]);
                            }
                            
                            if( !empty( $data[$thumbnail_i] ) ){
                                $image_id = get_product_image_id( $data[$thumbnail_i] );
                                $product->set_image_id( $image_id );
                            }
                            
                            if( !empty( $data[$gallery_i] ) ){
                                $image_ids = array();
                                foreach( json_decode($data[$gallery_i], true) as $image_url ){
                                    $image_ids[] = get_product_image_id( $image_url );
                                }
                                
                                if( !empty( $image_ids ) ){
                                    $product->set_gallery_image_ids($image_ids);
                                }
                            }
                            
                            if( !empty( $data[$cat_i] ) ){
                                $get_categories_id = get_category_ids_from_titles(implode(',', json_decode($data[$cat_i], true)));
                                $product->set_category_ids($get_categories_id);
                            }
                            
                            if( !empty( $data[$status_i] ) ){
                                $product->set_status( $data[$status_i] );
                            }
                        
                            if( !empty( $data[$attribute_i] ) ){
                                $attributes = array();
                                $exported_attributes = json_decode( $data[$attribute_i], true );
                                foreach( $exported_attributes as $exp_key => $ex_attr ){
                                    $attribute = new WC_Product_Attribute();
                                    $attribute->set_name( $exp_key );
                                    if( !empty($ex_attr['values']) ){
                                        $options = explode( ' | ', $ex_attr['values'] );
                                        $attribute->set_options( $options );
                                    }
                                    $attribute->set_position( 0 );
                                    ( $ex_attr['visible'] == 1 ) ? $attribute->set_visible( true ) : $attribute->set_visible( false );
                                    ( $ex_attr['variation'] == 1 ) ? $attribute->set_variation( true ) : $attribute->set_variation( false );
                                    $attributes[] = $attribute;
                                }
                                if( !empty( $attributes ) ){
                                    $product->set_attributes( $attributes );
                                }
                            }
                            
                            $product_id = $product->save();
                            if( !empty( $data[ $variation_i ] ) ){
                                $exp_variations = json_decode( $data[ $variation_i ], true );
                                usort($exp_variations, 'compare_by_price');
                                
                                if( !empty( $exp_variations ) ){
                                    foreach( $exp_variations as $exp_var ){
                                        $variation = new WC_Product_Variation();
                                        $variation->set_parent_id($product->get_id());
                                        if (!empty($variation_data['sku'])) {
                                            $variation->set_sku($variation_data['sku']);
                                        }
                                        $variation->set_price( $exp_var['price'] );
                                        
                                        $attributes = array();
                                        $meta_data = array();
                                        foreach ($exp_var['meta'] as $key => $value) {
                                            if (strpos($key, 'attribute_') === 0) {
                                                $attribute_name = str_replace('attribute_', '', $key);
                                                $attributes[$attribute_name] = $value;
                                            } else {
                                                $meta_data[$key] = $value;
                                            }
                                        }
                                        $variation->set_attributes($attributes);
                                        $variation_id = $variation->save();
                                        
                                        if( $variation_id ){
                                            foreach ($meta_data as $meta_key => $meta_value) {
                                                update_post_meta($variation_id, $meta_key, $meta_value);
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if( $product_id ){
                                $metas_tax = array();
                                if( !empty( $data[$price_i] ) ){
                                    $product->set_price($data[$price_i]);
                                    update_post_meta($product_id, '_price', $data[$price_i]);
                                    update_post_meta($product_id, '_regular_price', $data[$price_i]);
                                }
                                if( !empty( $meta_keys ) ){
                                    foreach( $meta_keys as $m_i => $meta_value ){
                                        if( $meta_value == 'typical_effects' || $meta_value == 'common_usage' || $meta_value == 'flavors' || $meta_value == 'aromas' || $meta_value == 'store_city' ){
                                            // array_push( $metas_tax, str_replace('_', '-', strtolower($meta_value)) );
                                            if( $meta_value == 'store_city' ){
                                                $meta_value = 'city';
                                            }
                                            $term_ids = array();
                                            if( !empty( $data[$m_i] ) ){
                                                foreach( json_decode($data[$m_i], true) as $term_name ){
                                                    
                                                    $term = get_term_by('name', $term_name, strtolower(str_replace('_', '-', $meta_value)));
                                                    // $term = get_term_by('name', $term_name, $meta_value);
                                                    
                                                    if( false !== $term ){
                                                        $term_ids[] = $term->term_id;
                                                    } else{
                                                        $new_term = wp_insert_term($term_name, strtolower(str_replace('_', '-', $meta_value)));
                                                        // $new_term = wp_insert_term($term_name, $meta_value);
                                                        $term_ids[] = $new_term->ID;
                                                    }
                                                    
                                                }
                                                
                                                if( !empty( $term_ids ) ){ 
                                                    update_field($meta_value, $term_ids, $product_id);
                                                }
                                            }
                                        }else{
                                            update_post_meta( $product_id, $meta_value, $data[$m_i] );
                                        }
                                    }
                                }
                                
                                /*if( !empty( $taxonomy_keys ) ){
                                    foreach( $taxonomy_keys as $tax_i => $tax ){
                                        $term_ids = array();
                                        if( !empty( $data[$tax_i] ) ){
                                            foreach( json_decode($data[$tax_i], true) as $term_name ){
                                                if( !in_array( $term_name, $metas_tax ) ){
                                                    $term = term_exists($term_name, $tax);
                                                    if (!$term) {
                                                        $term = wp_insert_term($term_name, $tax);
                                                    }
                                                    $term_id = is_array($term) ? $term['name'] : $term;
                                                    wp_set_object_terms($product_id, $term_id, $tax);
                                                    
                                                }
                                            }
                                            
                                        }
                                        
                                    }
                                }*/
                                
                            }
                            $product->save();
                            
                        }
                    }
                }
                
                
                
            }
            
            fclose($handle);
            echo '<div class="updated"><p>Products imported successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Failed to open the CSV file.</p></div>';
        }
    }
}

// Add a custom admin menu item for import
function custom_import_menu_clean() {
    add_menu_page(
        'Import WooCommerce Products',
        'Import Products',
        'manage_options',
        'custom-import-products-clean',
        'custom_import_woocommerce_products_clean_form'
    );
}

function custom_import_woocommerce_products_clean_form() {
    ?>
    <div class="wrap">
        <h1>Import WooCommerce Products</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="import_csv" required />
            <input type="submit" value="Import Products" class="button-primary" />
        </form>
    </div>
    <?php
    custom_import_woocommerce_products_clean();
}

add_action('admin_menu', 'custom_import_menu_clean');


function export_categories_to_csv_based_on_ids($category_ids) {
        
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'include' => $category_ids,
    ));

    $formatted_categories = format_categories($categories);
    return $formatted_categories;

}

function format_categories($categories) {
    $formatted_categories = array();
    $category_paths = array();
    $categories_by_id = array();

    foreach ($categories as $category) {
        $categories_by_id[$category->term_id] = $category;
    }

    foreach ($categories as $category) {
        $path = build_category_path($category, $categories_by_id);
        if ($path) {
            $category_paths[$category->term_id] = $path;
        }
    }

    foreach ($category_paths as $path) {
        $formatted_categories[] = implode(' > ', array_reverse($path));
    }

    return array_unique($formatted_categories);
}
    
function build_category_path($category, $categories_by_id) {
    $path = array();
    while ($category) {
        $path[] = $category->name;
        if ($category->parent && isset($categories_by_id[$category->parent])) {
            $category = $categories_by_id[$category->parent];
        } else {
            $category = null;
        }
    }
    return $path;
}


function get_category_ids_from_titles( $category_string ){
    global $wpdb;
    
    $category_paths = explode(',', $category_string);

    $category_ids = array();

    foreach ($category_paths as $category_path) {
        $parent_id = 0;
        $category_names = explode('>', $category_path);
        $last_category_id = null;

        foreach ($category_names as $category_name) {
            
            $category_id = get_category_id($category_name, $parent_id);
            
            if ($category_id) {
                
                $parent_id = $category_id;
                $last_category_id = $category_id;
                
            } else {
                
                error_log("Category not found: $category_name under parent ID: $parent_id");
                break;

            }
        }

        if ($last_category_id && !in_array($last_category_id, $category_ids)) {
            $category_ids[] = $last_category_id;
        }
    }

    return $category_ids;
}

function get_category_id($category_name, $parent_id) {
    
    global $wpdb;
    if( 0 != $parent_id ){
        
        $args = array(
            'taxonomy'   => 'product_cat',
            'parent'     => $parent_id,
            'hide_empty' => false,
        );

        $child_exist = array();
        $child_terms = get_terms($args);
        if( $child_terms ){
            foreach ($child_terms as $child) {
                $term = get_term_by('name', $category_name, 'product_cat');
                if( $term->term_name == $child->term_name ){
                    $child_exist[] = $child->term_id;
                }
            }
        }
        if( !empty($child_exist) ){
            return $child_exist[0];
        }else{
            $new_term = wp_insert_term($category_name, 'product_cat', array('parent' => $parent_id)); 
            return $new_term->term_id;
        }
        
    }else{
        
        $term = get_term_by('name', $category_name, 'product_cat');

        if( $term ){
    
            return $term->term_id;
    
        }else{
    
            $new_term = wp_insert_term($category_name, 'product_cat'); 
            return $new_term['term_id'];
    
        }
        
    }
    
    /*$term = get_term_by('name', $category_name, 'product_cat');

    if( $term ){

        return $term->term_id;

    }else{

        $new_term = wp_insert_term($category_name, 'product_cat', array('parent' => $parent_id)); 
        return $new_term['term_id'];

    }*/
    
}

function get_product_image_id( $image_url ){
    
	$upload_dir = wp_upload_dir();
	$image_data = file_get_contents($image_url);
	$filename = basename($image_url);
	if (wp_mkdir_p($upload_dir['path'])) {
		$file = $upload_dir['path'] . '/' . $filename;
	} else {
		$file = $upload_dir['basedir'] . '/' . $filename;
	}
	file_put_contents($file, $image_data);
	$wp_filetype = wp_check_filetype($filename, null);
	$attachment = array(
		'post_mime_type' => $wp_filetype['type'],
		'post_title' => sanitize_file_name($filename),
		'post_content' => '',
		'post_status' => 'inherit'
	);
	$attach_id = wp_insert_attachment($attachment, $file, $product_id);
	require_once(ABSPATH . 'wp-admin/includes/image.php');
	$attach_data = wp_generate_attachment_metadata($attach_id, $file);
	wp_update_attachment_metadata($attach_id, $attach_data);
	return $attach_id;
	
}

function compare_by_price($a, $b) {
    return $b['price'] <=> $a['price'];
}